#include <cstdio>
#define N 10010
#define M 100010
#define R 20010

int k, n, m;
int a[M], cnt[R];

struct Queue {
    int frt, rear, siz, cap;
    int data[N];
};

Queue hist, cache;

bool IsQueueFull(Queue* queue) {
    return queue->siz == queue->cap;
}

bool IsQueueEmpty(Queue* queue) {
    return queue->siz == 0;
}

void Enqueue(Queue* q, int x) {
    if (IsQueueFull(q)) {
        q->frt = (q->frt + 1) % q->cap;
        q->siz--;
    }
    q->rear = (q->rear + 1) % q->cap;
    q->data[q->rear] = x;
    q->siz++;
    return;
}

bool InCache(int x) {
    for (int i = 0; i < cache.siz; i++) {
        int ind = (cache.frt + i) % cache.cap;
        if (cache.data[ind] == x) {
            return true;
        }
    }
    return false;
}

void Remove(Queue* q, int x) {
    int tsiz = 0;
    int tdata[M];
    for (int i = 0; i < q->siz; i++) {
        int ind = (q->frt + i) % q->cap;
        if (q->data[ind] != x) {
            tdata[tsiz] = q->data[ind];
            tsiz++;
        }
    }
    for (int i = 0; i < tsiz; i++) {
        q->data[i] = tdata[i];
    }
    q->frt = 0, q->rear = tsiz - 1, q->siz = tsiz;
    return;
}

void Read() {
    scanf("%d %d %d", &k, &n, &m);
    for (int i = 0; i < m; i++) {
        scanf("%d", &a[i]);
    }
    return;
}

void Init() {
    hist.frt = 0, hist.rear = -1, hist.siz = 0, hist.cap = n;
    cache.frt = 0, cache.rear = -1, cache.siz = 0, cache.cap = n;
    return;
}

void Solve() {
    for (int i = 0; i < m; i++) {
        if (InCache(a[i])) {
            Remove(&cache, a[i]), Enqueue(&cache, a[i]);
        }
        else {
            cnt[a[i]]++;
            if (cnt[a[i]] == k) {
                Remove(&hist, a[i]), cnt[a[i]] = 0;
                Remove(&cache, a[i]), Enqueue(&cache, a[i]);
            }
            else {
                if (IsQueueFull(&hist)) {
                    cnt[hist.data[hist.frt]]--;
                }
                Enqueue(&hist, a[i]);
            }
        }
    }
    return;
}

void Print() {
    if (IsQueueEmpty(&hist)) {
        printf("-\n");
    }
    else {
        for (int i = 0; i < hist.siz; i++) {
            int ind = (hist.frt + i) % hist.cap;
            printf("%d%c", hist.data[ind], i == hist.siz - 1 ? '\n' : ' ');
        }
    }
    if (IsQueueEmpty(&cache)) {
        printf("-\n");
    }
    else {
        for (int i = 0; i < cache.siz; i++) {
            int ind = (cache.frt + i) % cache.cap;
            printf("%d%c", cache.data[ind], i == cache.siz - 1 ? '\n' : ' ');
        }
    }
    return;
}

int main()
{
    Read();
    Init();
    Solve();
    Print();
    return 0;
}