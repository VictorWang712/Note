#include <cstdio>
#include <list>
#include <map>
#define N 10010
#define M 100010
#define R 20010

int k, n, m, hsiz, csiz;
int a[M], cnt[R];

std::list <int> hist, cache; // id: hist - 0, cache - 1
std::map<int, std::list<int>::iterator> hmap, cmap;

void Dequeue(int id) {
    if (id == 0) {
        if (hist.empty() == false) {
            int val = hist.front();
            auto it = hmap.find(val);
            hmap.erase(it);
            hist.pop_front(), cnt[val] = 0;
        }
    }
    if (id == 1) {
        if (cache.empty() == false) {
            int val = cache.front();
            auto it = cmap.find(val);
            cmap.erase(it);
            cache.pop_front();
        }
    }
    return;
}

void Enqueue(int id, int val) {
    if (id == 0) {
        if (hsiz == n) {
            Dequeue(0);
            hsiz--;
        }
        hist.push_back(val);
        hmap.insert({val, --hist.end()});
        hsiz++;
    }
    if (id == 1) {
        if (csiz == n) {
            Dequeue(1);
            csiz--;
        }
        cache.push_back(val);
        cmap.insert({val, --cache.end()});
        csiz++;
    }
    return;
}

void Remove(int id, int val) {
    if (id == 0) {
        auto it = hmap.find(val);
        if (it != hmap.end()) {
            hist.erase(it->second);
            hmap.erase(it);
            hsiz--;
        }
    }
    if (id == 1) {
        auto it = cmap.find(val);
        if (it != cmap.end()) {
            cache.erase(it->second);
            cmap.erase(it);
            csiz--;
        }
    }
    return;
}

void Read() {
    scanf("%d %d %d", &k, &n, &m);
    for (int i = 0; i < m; i++) {
        scanf("%d", &a[i]);
    }
    return;
}

void Solve() {
    for (int i = 0; i < m; i++) {
        if (cmap.find(a[i]) != cmap.end()) {
            Remove(1, a[i]);
            Enqueue(1, a[i]);
        }
        else {
            cnt[a[i]]++;
            if (cnt[a[i]] == k) {
                Remove(0, a[i]), cnt[a[i]] = 0;
                Enqueue(1, a[i]);
            }
            else {
                Remove(0, a[i]), Enqueue(0, a[i]);
            }
        }
    }
    return;
}

void Print() {
    if (hist.empty() == true) {
        printf("-\n");
    }
    else {
        for (auto it = hist.begin(); it != hist.end(); it++) {
            printf("%d%c", *it, std::next(it) == hist.end() ? '\n' : ' ');
        }
    }
    if (cache.empty() == true) {
        printf("-\n");
    }
    else {
        for (auto it = cache.begin(); it != cache.end(); it++) {
            printf("%d%c", *it, std::next(it) == cache.end() ? '\n' : ' ');
        }
    }
    return;
}

int main()
{
    Read();
    Solve();
    Print();
    return 0;
}