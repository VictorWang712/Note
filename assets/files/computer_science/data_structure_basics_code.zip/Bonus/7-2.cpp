#include <cstdio>
#include <functional>
#include <vector>
#include <queue>
#define N 100010

int n, m, ind = 0, lst = -1;
int a[N];


std::priority_queue<int, std::vector<int>, std::greater<int>> heap;
std::vector<int> cache;

int main()
{
    scanf("%d %d", &n, &m);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < m; i++) {
        heap.push(a[i]);
        ind++;
    }
    while (heap.empty() == false) {
        int frt = heap.top();
        heap.pop();
        lst = frt, printf("%d", frt);
        if (ind < n) {
            if (a[ind] >= lst) {
                heap.push(a[ind]);
            }
            else {
                cache.push_back(a[ind]);
            }
            ind++;
        }
        if (heap.empty() == false) {
            printf(" ");
        }
        if (heap.empty() == true && cache.empty() == false) {
            printf("\n");
            for (int i : cache) {
                heap.push(i);
            }
            cache.clear();
            lst = -1;
        }
    }
    if (cache.empty() == false) {
        printf("\n");
        auto it = cache.begin();
        while (it != cache.end()) {
            printf("%d%c", *it, std::next(it) == cache.end() ? '\n' : ' ');
        }
    }
    return 0;
}