#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <direct.h>

#define N 100010 // Maximum array size definition

int n, c, flag, K; // n: number of elements, c: target sum value, flag: indicates if a valid pair is found, K: number of iterations for timing
int a[N]; // Array to store elements
double single_dur, total_dur; // Variables to store single and total execution durations
char input_file[30] = "../data/input/0.in", output_file[30] = "../data/binary_search/0.out"; // File paths for input and output

clock_t start, stop, single_ticks, total_ticks; // Variables for measuring clock ticks

int Compare(const void * a, const void * b) { // Comparator function for qsort
   return (*(int*)a - *(int*)b); // Compare two integers and return the difference
}

int BinarySearch(int l, int r, int val) { // Recursive binary search implementation
    if (l > r) { // Base case: search space exhausted
        return -1;  // Return -1 if the value is not found
    }
    int mid = (l + r) / 2; // Calculate mid point
    if (a[mid] == val) { // Check if the mid element is the target value
        return mid; // Return the index if the target value is found
    }
    else if (a[mid] < val) { // If the mid element is less than the target value
        return BinarySearch(mid + 1, r, val); // Search the right half recursively
    }
    else { // If the mid element is greater than the target value
        return BinarySearch(l, mid - 1, val); // Search the left half recursively
    }
}

void Function(char* input_file, char* output_file) {
    freopen(input_file, "r", stdin);
    freopen(output_file, "w", stdout);

    scanf("%d %d", &n, &c);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    qsort(a, n, sizeof(int), Compare); // Sort the array using qsort with the Compare function
    for (int i = 0; i < n; i++) { // Loop through each element in the array
        int ret = BinarySearch(i + 1, n - 1, c - a[i]); // Search for the complement value in the array
        if (ret != -1) { // If a valid pair is found
            flag = 1; // Set flag to indicate a valid pair is found
            printf("(%d, %d)\n", a[i], a[ret]); // Print the successful pair with indices and values
        }
    }
    if (flag == 0) { // If no valid pair is found, print a message indicating so
        printf("No valid pairs found\n");
    }

    fclose(stdin);
    fclose(stdout);
    return;
}

int main() 
{
    _mkdir("../data/binary_search"); // Create a directory for output files
    for (int i = 0; i < 8; i++) { // Loop through 8 input files
        input_file[14]++, output_file[22]++; // Increment file names for the next iteration

        // Initial run to estimate K
        start = clock();
        Function(input_file, output_file);
        stop = clock();
        single_ticks = stop - start; // Calculate the number of ticks for the single run
        if (single_ticks > 0) { // If the single run took measurable time
            K = 1000 / single_ticks + 1; // Calculate K to ensure sufficient iterations for accurate timing
        }
        else { // If the single run took negligible time
            K = 1000; // Default to 1000 iterations
        }

        // Formal measurement
        start = clock();
        for (int j = 0; j < K; j++) {
            Function(input_file, output_file);
        }
        stop = clock();
        total_ticks = stop - start; // Calculate total ticks for all iterations
        total_dur = (double)total_ticks / CLOCKS_PER_SEC; // Convert total ticks to seconds
        single_dur = total_dur / K; // Calculate average time per iteration

        if (i == 0) { // For the first iteration, open the output file in write mode
            freopen("../document/binary_search_time_consume.txt", "w", stdout);
        }
        else { // For subsequent iterations, open the output file in append mode
            freopen("../document/binary_search_time_consume.txt", "a", stdout);
        }
        printf("Input File: %d.in  Iterations (K): %d  Ticks: %ld  Total Time: %.6f  Avg Time: %.6f\n", i + 1, K, total_ticks, total_dur, single_dur); // Print timing results
        fclose(stdout);
    }
    return 0;
}