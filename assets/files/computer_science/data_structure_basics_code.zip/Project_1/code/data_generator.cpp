#include <iostream>
#include <fstream>
#include <random>
#include <vector>
#include <ctime>
#include <filesystem>

const std::vector<int> n_values = {1000, 5000, 10000, 20000, 40000, 60000, 80000, 100000};
std::vector<int> a;

int main() {
    std::mt19937 rng(time(nullptr));
    std::uniform_int_distribution<int> c_dist(9000000, 10000000);
    std::filesystem::create_directories("../data/input");
    for (size_t idx = 0; idx < n_values.size(); idx++) {
        int n = n_values[idx];
        int c = c_dist(rng);
        a.resize(n);
        std::uniform_int_distribution<int> a_dist(1, 10000000);  // Random number distribution for array elements
        for (auto &num : a) { // Generate initial random array
            num = a_dist(rng);  // Assign random values to array elements
        }
        // Randomly select two distinct positions
        std::uniform_int_distribution<int> index_dist(0, n - 1);  // Distribution for index selection
        int i = index_dist(rng);
        int j;
        do {
            j = index_dist(rng);
        } while (i == j);
        // Ensure there exists a pair a[i] + a[j] = c
        std::uniform_int_distribution<int> x_dist(1, c - 1); // Create distribution for the x value (1 <= x <= c - 1)
        int x = x_dist(rng); // Generate random x value
        a[i] = x; // Set a[i] to x
        a[j] = c - x; // Set a[j] to c - x to satisfy sum condition
        // File output operations
        std::string filename = "../data/input/" + std::to_string(idx + 1) + ".in"; // Construct filename pattern: ../data/input/1.in, ../data/input/2.in, etc.
        std::ofstream out(filename); // Create and open output file stream
        out << n << " " << c << "\n"; // Write header line with n and c values
        for (int k = 0; k < n; k++) { // Write array elements with space separation
            if (k > 0) out << " "; // Add space separator between elements
            out << a[k]; // Write array element to file
        }
        out << "\n"; // End with newline
    }
    return 0;
}