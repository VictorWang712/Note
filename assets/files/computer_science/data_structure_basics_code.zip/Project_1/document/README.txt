README

This directory contains three files:

report.pdf:

The project report document, which elaborates on the addressed issues, implemented algorithms, analytical methodologies, and code implementation details. This file provides a comprehensive understanding of the project objectives and technical execution.

sequence_search_time_consume.txt, binary_search_time_consume.txt:

The latter two files record runtime performance metrics of the implemented algorithms. It is recommended to review these files after studying report.pdf and the source code to evaluate the practical performance characteristics of the algorithms in operational contexts.