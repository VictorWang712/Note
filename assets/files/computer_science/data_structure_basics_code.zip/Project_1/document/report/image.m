% Data extraction
N = [1000, 5000, 10000, 20000, 40000, 60000, 80000, 100000];
Algo1_Duration = [85, 973.2, 3995.5, 14837.5, 52000, 122200, 205400, 353400];
Algo2_Duration = [47.8, 200.4, 420.3, 1065.2, 2434.8, 2500, 3363.6, 4400];

% Generate reference lines
x_ref = linspace(min(N), max(N), 500); 
k1 = 0.8e-6;   % Scaling factor for N²
k2 = 0.3e-3;   % Scaling factor for Nlog2N
ref_N2 = (k1 * x_ref.^2) * 40;
ref_NlogN = (k2 * x_ref .* log2(x_ref)) * 7;

% Create figure with enhanced styling
figure('Color','white','Position',[100 100 800 600]);
hold on;

% Plot data points with custom markers
scatter(N, Algo1_Duration, 120, [0.8 0.2 0.2], 'o', ...
    'LineWidth',1.5, 'MarkerFaceColor',[0.9 0.2 0.2], ...
    'DisplayName','Algorithm 1');

scatter(N, Algo2_Duration, 120, [0.2 0.2 0.8], 'd', ...
    'LineWidth',1.5, 'MarkerFaceColor',[0.2 0.4 0.9], ...
    'DisplayName','Algorithm 2');

% Plot reference lines
p1 = plot(x_ref, ref_N2, '--', 'Color',[0.3 0.3 0.3], ...
         'LineWidth',1.8, 'DisplayName','O(N^{2})');
p2 = plot(x_ref, ref_NlogN, '-.', 'Color',[0.1 0.6 0.2], ...
         'LineWidth',1.8, 'DisplayName','O(NlogN)');

% Axis and label configuration
set(gca, 'XScale','log', 'YScale','log', ...
         'FontSize',12, 'FontName','Arial', ...
         'XMinorGrid','on', 'YMinorGrid','on', ...
         'GridAlpha',0.3, 'MinorGridAlpha',0.15);

xlabel('Data Size (N)', 'FontSize',14, 'FontWeight','bold');
ylabel('Duration (×10^{-6} seconds)', 'FontSize',14, 'FontWeight','bold');
title('Algorithm Duration vs Complexity Reference', ...
      'FontSize',16, 'FontWeight','bold');

% Legend customization
legend('Location','northwest', ...
       'FontSize',12, ...
       'Box','off', ...
       'TextColor',[0.3 0.3 0.3]);

% Axis limits and ticks
xlim([800 1.5e5]);
ylim([10 1e6]);
xticks([1e3 1e4 1e5]);
xticklabels({'10^3','10^4','10^5'});
yticks(10.^[1:6]);
yticklabels({'10^1','10^2','10^3','10^4','10^5','10^6'});

% Add annotation
text(3e3, 5e5, {'Reference lines show','complexity trends'}, ...
     'FontSize',11, 'Color',[0.4 0.4 0.4], ...
     'VerticalAlignment','cap');

% Set figure background and grid
grid on;
box on;
set(gca, 'GridColor',[0.8 0.8 0.8]);
set(gcf, 'InvertHardcopy','off');

exportgraphics(gcf, 'image.png', 'Resolution', 300);

hold off;