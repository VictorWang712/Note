# README

This directory contains four code files: `autograd.c`, `generator.py`, `validator.py`, and `auto_test.bat`.

- `autograd.c` is the core code of this project, implementing the automatic differentiation functionality.
- `generator.py` is a random generator for test data.
- `validator.py` is the correctness validator.
- `auto_test.bat` is the automated verification script.

I provide two methods for reproducing my experimental results on your local machine.

## Automatic (Recommended)

### Usage

I highly recommend using the automated script for efficient verification.

First, ensure that your computer has Python version 3.12 or above installed. If not, you can download and install it from the [official Python download page](https://www.python.org/downloads/).

After installing Python, you need to install the `numpy` and `sympy` libraries. You can do this by entering the following commands in your terminal:

```bat
pip install numpy
pip install sympy
```

Once the above steps are completed, you can directly execute `auto_test.bat`.

### Successful Execution

If, after running `auto_test.bat` and waiting for a while (which may take some time), you see the following messages in the command line:

```bat
[INFO] C program compiled successfully.
[INFO] Random expression generation completed successfully.
[INFO] All expressions have been validated successfully.
```

This indicates that the automated verification script has executed successfully.

At this point, you can check the generated content in the `benchmark` directory:

- The `input\random` directory should contain 10 files, which are the randomly generated test data.
- In the `output` directory, the `sample` subdirectory should contain 6 files, and the `random` subdirectory should contain 10 files. These files represent the program's output corresponding to the inputs from the `input` directory.
- The `result` directory should contain 2 files, representing the program's test results for the `sample` and `random` inputs.

Furthermore, you can execute the automated script `auto_test.bat` multiple times. After each execution, you will notice that all files in the `benchmark` directory, except those in `input\sample`, will be updated with the results of the new random test.

It is worth mentioning that before your first execution of the automated script, the above folders should already contain results from a pre-generated random test. This pre-generated result is provided to facilitate your inspection. These contents will be overwritten after your first execution of `auto_test.bat`.

### Execution Failure

If the command line output enters an infinite loop or reports other errors after running `auto_test.bat`, unfortunately, the automated script has failed.

In most cases (if not always), this situation arises due to issues with your Python installation or environment configuration. This program has been successfully tested on multiple devices with different system versions and Python versions, so please trust that the problem does not lie in the program itself.

In this case, please carefully follow the instructions above to reconfigure your environment. Regrettably, due to anonymization requirements, you cannot contact me for assistance, although I am willing to help. If you are still unable to run the script successfully, you may proceed with the manual method described below.

## Manual

Ensure that your computer has a GCC compiler supporting the C99 standard.

You can compile the program by entering the following command in the terminal:

```bat
gcc autograd.c -o autograd.exe -lm
```

Then, you can run the program by entering:

```bat
.\autograd.exe
```

You may manually input the algebraic expressions for automatic differentiation via the command line. Please strictly follow the expression format specified in the project requirements.

For your convenience, I have provided 6 sample test cases in the `benchmark\input\sample` directory. These cases cover all complex scenarios and are representative. You can use them by simply copying and pasting.

Regarding output validation, as automated numerical verification is unavailable, you will need to manually simplify and verify the expressions.
