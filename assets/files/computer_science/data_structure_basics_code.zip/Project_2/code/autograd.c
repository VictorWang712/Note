#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int pos, varcount;  // Position in input and variable count
char input[256], *varlist[256];  // Input buffer and list of variables

typedef enum {  // Enum for different types of nodes in the expression tree
    CONST, VAR, ADD, SUB, MUL, DIV, POW, LN, LOG, COS, SIN, TAN, EXP
} NodeType;

typedef struct Node {  // Struct for a node in the expression tree
    NodeType type;  // Type of the node
    int value;  // Value if the node is a constant
    char *var;  // Variable name if the node is a variable
    struct Node *left, *right;  // Pointers to left and right children
} Node;

/*Function Statements*/

void SkipSpace();
char Current();
int Match(char c);
void FreeTree(Node *node);
Node *NewConst(int value);
Node *NewVar(const char *varName);
Node *NewNode(NodeType type, Node *left, Node *right);
Node *CopyNode(const Node *node);
int EqualNode(const Node *a, const Node *b);
Node *ParseNumber();
Node *ParseFuncOrVar();
Node *ParsePrimary();
Node *ParseFactor();
Node *ParseTerm();
Node *ParseExpression();
void Traverse(Node *node, char *varlist[], int *varcount);
int Compare(const void *a, const void *b);
Node *Differentiate(const Node *node, const char *var);
Node *Simplify(Node *node);
int Precedence(const Node *node);
void Output(const Node *node, int prtprcd);

/*Utility Functions*/

void SkipSpace() {  // Function to skip spaces in the input
    while (input[pos] && isspace(input[pos])) {  // While current character is space
        pos++;  // Move to next character
    }
    return;  // Return from function
}

char Current() {  // Function to get the current character
    SkipSpace();  // Skip spaces
    return input[pos];  // Return current character
}

int Match(char c) {  // Function to match and consume a character
    SkipSpace();  // Skip spaces
    if (input[pos] == c) {  // If current character matches the expected one
        pos++;  // Consume the character
        return 1;  // Return success
    }
    else {
        return 0;  // Return failure
    }
}

void FreeTree(Node *node) {  // Function to free memory allocated for a tree
    if (node == NULL) {  // If node is null, return
        return;
    }
    FreeTree(node->left), FreeTree(node->right);  // Free left and right subtrees
    if (node->type == VAR && node->var != NULL) {  // If node is a variable and has a variable name
        free(node->var);  // Free the variable name
    }
    free(node);  // Free the node itself
    return;
}

/*Node Operations*/

Node *NewConst(int value) {  // Function to create a new constant node
    Node *node = (Node *)malloc(sizeof(Node));  // Allocate memory for the node
    node->type = CONST, node->value = value, node->var = NULL, node->left = NULL, node->right = NULL;  // Initialize node
    return node;  // Return the created node
}

Node *NewVar(const char *var) {  // Function to create a new variable node
    Node *node = (Node *)malloc(sizeof(Node));  // Allocate memory for the node
    node->type = VAR, node->value = 0, node->var = strdup(var), node->left = NULL, node->right = NULL;  // Initialize node
    return node;  // Return the created node
}

Node *NewNode(NodeType type, Node *left, Node *right) {  // Function to create a new node with children
    Node *node = (Node *)malloc(sizeof(Node));  // Allocate memory for the node
    node->type = type, node->value = 0, node->var = NULL, node->left = left, node->right = right;  // Initialize node
    return node;  // Return the created node
}

Node *CopyNode(const Node *node) {  // Function to create a copy of a node
    if (node == NULL) {  // If node is null, return null
        return NULL;
    }
    Node *newnode = (Node *)malloc(sizeof(Node));  // Allocate memory for the new node
    newnode->type = node->type;  // Copy type
    newnode->value = node->value;  // Copy value
    if (node->type == VAR && node->var != NULL) {  // If node is a variable, copy the variable name
        newnode->var = strdup(node->var);
    }
    else {
        newnode->var = NULL;  // Else set variable name to null
    }
    newnode->left = CopyNode(node->left);  // Copy left subtree
    newnode->right = CopyNode(node->right);  // Copy right subtree
    return newnode;  // Return the copied node
}

int EqualNode(const Node *a, const Node *b) {  // Function to check if two nodes are equal
    if (a == NULL && b == NULL) {  // If both nodes are null, return true
        return 1;
    }
    else if (a == NULL || b == NULL) {  // If one of the nodes is null, return false
        return 0;
    }
    if (a->type != b->type) {  // If node types differ, return false
        return 0;
    }
    switch (a->type) {  // Check based on node type
        case CONST:
            return a->value == b->value;  // Check if constant values are equal
        case VAR:
            return strcmp(a->var, b->var) == 0;  // Check if variable names are equal
        case LN:
        case COS:
        case SIN:
        case TAN:
        case EXP:
            return EqualNode(a->left, b->left);  // Check equality of left subtree for single operand functions
        default:
            return EqualNode(a->left, b->left) && EqualNode(a->right, b->right);  // Check equality of both subtrees
    }
}

/*Parsing Expression*/

Node *ParseNumber() {  // Function to parse a number
    SkipSpace();  // Skip spaces
    int tmp = pos, len, val;  // Temporary position, length, and value
    char buffer[256];  // Buffer for number string
    while (input[pos] && isdigit(input[pos])) {  // While current character is a digit
        pos++;  // Move to next character
    }
    len = pos - tmp;  // Calculate length of number
    strncpy(buffer, input + tmp, len), buffer[len] = '\0';  // Copy number to buffer and null-terminate
    val = atoi(buffer);  // Convert string to integer
    return NewConst(val);  // Return new constant node
}

Node *ParseFuncOrVar() {  // Function to parse a function or variable
    SkipSpace();  // Skip spaces
    int tmp = pos, len;  // Temporary position and length
    char buffer[256];  // Buffer for function or variable name
    while (input[pos] && islower(input[pos])) {  // While current character is lowercase
        pos++;  // Move to next character
    }
    if (tmp == pos) {  // If no name was found
        printf("error: Expected function name or variable\n");  // Print error
        exit(1);  // Exit program
    }
    len = pos - tmp;  // Calculate length of name
    strncpy(buffer, input + tmp, len), buffer[len] = '\0';  // Copy name to buffer and null-terminate
    SkipSpace();  // Skip spaces
    if (Current() == '(') {  // If current character is '('
        Match('(');  // Match and consume '('
        if (strcmp(buffer, "ln") == 0) {  // If function is ln
            Node *expr = ParseExpression();  // Parse the expression
            if (Match(')') == 0) {  // If ')' is not found
                printf("error: Missing ')' in the ln function\n");  // Print error
                exit(1);  // Exit program
            }
            return NewNode(LN, expr, NULL);  // Return new node for ln
        }
        else if (strcmp(buffer, "log") == 0) {  // If function is log
            Node *expr1 = ParseExpression();  // Parse first expression
            if (Match(',') == 0) {  // If ',' is not found
                printf("error: Missing ',' in the log function\n");  // Print error
                exit(1);  // Exit program
            }
            Node *expr2 = ParseExpression();  // Parse second expression
            if (Match(')') == 0) {  // If ')' is not found
                printf("error: Missing ')' in the log function\n");  // Print error
                exit(1);  // Exit program
            }
            return NewNode(LOG, expr1, expr2);  // Return new node for log
        }
        else if (strcmp(buffer, "cos") == 0) {  // If function is cos
            Node *expr = ParseExpression();  // Parse the expression
            if (Match(')') == 0) {  // If ')' is not found
                printf("error: Missing ')' in the cos function\n");  // Print error
                exit(1);  // Exit program
            }
            return NewNode(COS, expr, NULL);  // Return new node for cos
        }
        else if (strcmp(buffer, "sin") == 0) {  // If function is sin
            Node *expr = ParseExpression();  // Parse the expression
            if (Match(')') == 0) {  // If ')' is not found
                printf("error: Missing ')' in the sin function\n");  // Print error
                exit(1);  // Exit program
            }
            return NewNode(SIN, expr, NULL);  // Return new node for sin
        }
        else if (strcmp(buffer, "tan") == 0) {  // If function is tan
            Node *expr = ParseExpression();  // Parse the expression
            if (Match(')') == 0) {  // If ')' is not found
                printf("error: Missing ')' in the tan function\n");  // Print error
                exit(1);  // Exit program
            }
            return NewNode(TAN, expr, NULL);  // Return new node for tan
        }
        else if (strcmp(buffer, "pow") == 0) {  // If function is pow
            Node *expr1 = ParseExpression();  // Parse first expression
            if (Match(',') == 0) {  // If ',' is not found
                printf("error: Missing ',' in the pow function\n");  // Print error
                exit(1);  // Exit program
            }
            Node *expr2 = ParseExpression();  // Parse second expression
            if (Match(')') == 0) {  // If ')' is not found
                printf("error: Missing ')' in the pow function\n");  // Print error
                exit(1);  // Exit program
            }
            return NewNode(POW, expr1, expr2);  // Return new node for pow
        }
        else if (strcmp(buffer, "exp") == 0) {  // If function is exp
            Node *expr = ParseExpression();  // Parse the expression
            if (Match(')') == 0) {  // If ')' is not found
                printf("error: Missing ')' in the exp function\n");  // Print error
                exit(1);  // Exit program
            }
            return NewNode(EXP, expr, NULL);  // Return new node for exp
        }
        else {  // If function name is unknown
            printf("error: Unknown function name\n");  // Print error
            exit(1);  // Exit program
        }
    }
    else {
        return NewVar(buffer);  // Return new variable node
    }
}

Node *ParsePrimary() {  // Function to parse a primary expression
    SkipSpace();  // Skip spaces
    if (Match('(')) {  // If current character is '('
        Node *expr = ParseExpression();  // Parse the expression
        if (Match(')') == 0) {  // If ')' is not found
            printf("error: Missing ')'\n");  // Print error
            exit(1);  // Exit program
        }
        return expr;  // Return the parsed expression
    }
    else if (isdigit(Current())) {  // If current character is a digit
        return ParseNumber();  // Parse and return a number
    }
    else if (islower(Current())) {  // If current character is lowercase
        return ParseFuncOrVar();  // Parse and return a function or variable
    }
    else {  // If unable to parse current character
        printf("error: Unable to parse the character '%c'\n", Current());  // Print error
        exit(1);  // Exit program
        return NULL;  // Return null
    }
}

Node *ParseFactor() {  // Function to parse a factor
    Node *left = ParsePrimary();  // Parse a primary expression
    SkipSpace();  // Skip spaces
    while (1) {  // Loop for parsing exponentiation
        if (Match('^')) {  // If current character is '^'
            Node *right = ParsePrimary();  // Parse the right operand
            left = NewNode(POW, left, right);  // Create a new node for the power
        }
        else {
            break;  // Break the loop if no '^' found
        }
        SkipSpace();  // Skip spaces
    }
    return left;  // Return the parsed factor
}

Node *ParseTerm() {  // Function to parse a term
    Node *left = ParseFactor();  // Parse a factor
    SkipSpace();  // Skip spaces
    while (1) {  // Loop for parsing multiplication and division
        if (Match('*')) {  // If current character is '*'
            Node *right = ParseFactor();  // Parse the right operand
            left = NewNode(MUL, left, right);  // Create a new node for multiplication
        }
        else if (Match('/')) {  // If current character is '/'
            Node *right = ParseFactor();  // Parse the right operand
            left = NewNode(DIV, left, right);  // Create a new node for division
        }
        else {
            break;  // Break the loop if no '*' or '/' found
        }
        SkipSpace();  // Skip spaces
    }
    return left;  // Return the parsed term
}

Node *ParseExpression() {  // Function to parse an expression
    Node *left = ParseTerm();  // Parse a term
    SkipSpace();  // Skip spaces
    while (1) {  // Loop for parsing addition and subtraction
        if (Match('+')) {  // If current character is '+'
            Node *right = ParseTerm();  // Parse the right operand
            left = NewNode(ADD, left, right);  // Create a new node for addition
        }
        else if (Match('-')) {  // If current character is '-'
            Node *right = ParseTerm();  // Parse the right operand
            left = NewNode(SUB, left, right);  // Create a new node for subtraction
        }
        else {
            break;  // Break the loop if no '+' or '-' found
        }
        SkipSpace();  // Skip spaces
    }
    return left;  // Return the parsed expression
}

/*Collecting Variations*/

void Traverse(Node *node, char *varlist[], int *varcount) {  // Function to traverse the tree and collect variables
    if (node == NULL) {  // If node is null, return
        return;
    }
    if (node->type == VAR) {  // If node is a variable
        int flag = 0;  // Flag to check if variable is already in list
        for (int i = 0; i < *varcount; i++) {  // Loop through variable list
            if (strcmp(node->var, varlist[i]) == 0) {  // If variable is found
                flag = 1;  // Set flag
                break;  // Break loop
            }
        }
        if (flag == 0) {  // If variable is not in list
            varlist[*varcount] = strdup(node->var);  // Add variable to list
            (*varcount)++;  // Increment variable count
        }
    }
    Traverse(node->left, varlist, varcount);  // Traverse left subtree
    Traverse(node->right, varlist, varcount);  // Traverse right subtree
    return;  // Return from function
}

/*Sorting Auxiliary Function*/

int Compare(const void *a, const void *b) {  // Function to compare strings for sorting
    const char *s1 = *(const char **)a;  // Pointer to first string
    const char *s2 = *(const char **)b;  // Pointer to second string
    return strcmp(s1, s2);  // Compare and return result
}

/*Symbol Differentiation*/

Node *Differentiate(const Node *node, const char *var) {  // Function to differentiate an expression
    if (node == NULL) {  // If node is null, return null
        return NULL;
    }
    if (node->type == CONST) {  // If node is a constant
        return NewConst(0);  // Derivative is zero
    }
    else if (node->type == VAR) {  // If node is a variable
        if (strcmp(node->var, var) == 0) {  // If variable matches the differentiation variable
            return NewConst(1);  // Derivative is one
        }
        else {
            return NewConst(0);  // Derivative is zero
        }
    }
    else if (node->type == ADD) {  // If node is addition
        return NewNode(ADD, Differentiate(node->left, var), Differentiate(node->right, var));  // Sum of derivatives
    }
    else if (node->type == SUB) {  // If node is subtraction
        return NewNode(SUB, Differentiate(node->left, var), Differentiate(node->right, var));  // Difference of derivatives
    }
    else if (node->type == MUL) {  // If node is multiplication
        Node *dl = Differentiate(node->left, var);  // Derivative of left operand
        Node *dr = Differentiate(node->right, var);  // Derivative of right operand
        Node *l = NewNode(MUL, dl, CopyNode(node->right));  // Left term of product rule
        Node *r = NewNode(MUL, CopyNode(node->left), dr);  // Right term of product rule
        return NewNode(ADD, l, r);  // Sum of product rule terms
    }
    else if (node->type == DIV) {  // If node is division
        Node *dl = Differentiate(node->left, var);  // Derivative of numerator
        Node *dr = Differentiate(node->right, var);  // Derivative of denominator
        Node *l = NewNode(MUL, dl, CopyNode(node->right));  // Left term of quotient rule
        Node *r = NewNode(MUL, CopyNode(node->left), dr);  // Right term of quotient rule
        Node *numerator = NewNode(SUB, l, r);  // Numerator of quotient rule
        Node *denominator = NewNode(POW, CopyNode(node->right), NewConst(2));  // Denominator of quotient rule
        return NewNode(DIV, numerator, denominator);  // Complete quotient rule
    }
    else if (node->type == POW) {  // If node is a power
        if (node->right->type == CONST) {  // If exponent is a constant
            int exponent = node->right->value;  // Get exponent value
            Node *newexponent = NewConst(exponent - 1);  // New exponent for derivative
            Node *power = NewNode(POW, CopyNode(node->left), newexponent);  // Adjusted power
            Node *df = Differentiate(node->left, var);  // Derivative of base
            Node *coefficient = NewConst(exponent);  // Coefficient for derivative
            return NewNode(MUL, coefficient, NewNode(MUL, df, power));  // Complete power rule
        }
        else {  // If exponent is not a constant
            Node *df = Differentiate(node->left, var);  // Derivative of base
            Node *dg = Differentiate(node->right, var);  // Derivative of exponent
            Node *lnf = NewNode(LN, CopyNode(node->left), NULL);  // Ln of base
            Node *l = NewNode(MUL, dg, lnf);  // Left term of chain rule
            Node *r = NewNode(DIV, NewNode(MUL, CopyNode(node->right), df), CopyNode(node->left));  // Right term of chain rule
            Node *sum = NewNode(ADD, l, r);  // Sum of terms
            return NewNode(MUL, CopyNode(node), sum);  // Complete chain rule
        }
    }
    else if (node->type == LN) {  // If node is ln
        Node *df = Differentiate(node->left, var);  // Derivative of argument
        return NewNode(DIV, df, CopyNode(node->left));  // Derivative of ln
    }
    else if (node->type == LOG) {  // If node is log
        Node *df = Differentiate(node->left, var);  // Derivative of first argument
        Node *dg = Differentiate(node->right, var);  // Derivative of second argument
        Node *lnf = NewNode(LN, CopyNode(node->left), NULL);  // Ln of first argument
        Node *lng1 = NewNode(LN, CopyNode(node->right), NULL);  // Ln of second argument
        Node *lng2 = NewNode(LN, CopyNode(node->right), NULL);  // Ln of second argument
        Node *l = NewNode(MUL, NewNode(DIV, df, CopyNode(node->left)), lng1);  // Left term of log rule
        Node *r = NewNode(MUL, NewNode(DIV, dg, CopyNode(node->right)), lnf);  // Right term of log rule
        Node *numerator = NewNode(SUB, l, r);  // Numerator of log rule
        Node *denominator = NewNode(POW, lng2, NewConst(2));  // Denominator of log rule
        return NewNode(DIV, numerator, denominator);  // Complete log rule
    }
    else if (node->type == COS) {  // If node is cos
        Node *df = Differentiate(node->left, var);  // Derivative of argument
        Node *sinf = NewNode(MUL, NewConst(-1), NewNode(SIN, CopyNode(node->left), NULL));  // Negative sin of argument
        return NewNode(MUL, df, sinf);  // Derivative of cos
    }
    else if (node->type == SIN) {  // If node is sin
        Node *df = Differentiate(node->left, var);  // Derivative of argument
        Node *cosf = NewNode(COS, CopyNode(node->left), NULL);  // Cos of argument
        return NewNode(MUL, df, cosf);  // Derivative of sin
    }
    else if (node->type == TAN) {  // If node is tan
        Node *df = Differentiate(node->left, var);  // Derivative of argument
        Node *cosf = NewNode(COS, CopyNode(node->left), NULL);  // Cos of argument
        Node *square = NewNode(POW, cosf, NewConst(2));  // Square of cos
        return NewNode(DIV, df, square);  // Derivative of tan
    }
    else if (node->type == EXP) {  // If node is exp
        Node *df = Differentiate(node->left, var);  // Derivative of argument
        Node *expf = NewNode(EXP, CopyNode(node->left), NULL);  // Exp of argument
        return NewNode(MUL, df, expf);  // Derivative of exp
    }
    else {  // If node type is unknown
        printf("error: Differentiation is not supported for node type %d\n", node->type);  // Print error
        exit(1);  // Exit program
        return NULL;  // Return null
    }
}

/*Simplifying Expression*/

Node *Simplify(Node *node) {  // Function to simplify an expression
    if (node == NULL) {  // If node is null, return null
        return NULL;
    }
    if (node->type == CONST) {  // If node is a constant
        return node;  // Return the node
    }
    else if (node->type == VAR) {  // If node is a variable
        return node;  // Return the node
    }
    else if (node->type == ADD) {  // If node is addition
        node->left = Simplify(node->left);  // Simplify left operand
        node->right = Simplify(node->right);  // Simplify right operand
        if (node->left->type == CONST && node->right->type == CONST) {  // If both operands are constants
            int sum = node->left->value + node->right->value;  // Calculate sum
            FreeTree(node->left);  // Free left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return NewConst(sum);  // Return new constant node
        }
        else if (node->left->type == CONST && node->left->value == 0) {  // If left operand is zero
            Node *ret = node->right;  // Return right operand
            FreeTree(node->left);  // Free left operand
            free(node);  // Free current node
            return ret;  // Return right operand
        }
        else if (node->right->type == CONST && node->right->value == 0) {  // If right operand is zero
            Node *ret = node->left;  // Return left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return ret;  // Return left operand
        }
        return node;  // Return the node
    }
    else if (node->type == SUB) {  // If node is subtraction
        node->left = Simplify(node->left);  // Simplify left operand
        node->right = Simplify(node->right);  // Simplify right operand
        if (node->left->type == CONST && node->right->type == CONST) {  // If both operands are constants
            int diff = node->left->value - node->right->value;  // Calculate difference
            FreeTree(node->left);  // Free left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return NewConst(diff);  // Return new constant node
        }
        else if (node->left->type == CONST && node->left->value == 0) {  // If left operand is zero
            Node *ret = NewNode(MUL, NewConst(-1), CopyNode(node->right));  // Return negation of right operand
            FreeTree(node->left);  // Free left operand
            free(node);  // Free current node
            return ret;  // Return negated right operand
        }
        else if (node->right->type == CONST && node->right->value == 0) {  // If right operand is zero
            Node *ret = node->left;  // Return left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return ret;  // Return left operand
        }
        return node;  // Return the node
    }
    else if (node->type == MUL) {  // If node is multiplication
        node->left = Simplify(node->left);  // Simplify left operand
        node->right = Simplify(node->right);  // Simplify right operand
        if (node->left->type == CONST && node->right->type == CONST) {  // If both operands are constants
            int prod = node->left->value * node->right->value;  // Calculate product
            FreeTree(node->left);  // Free left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return NewConst(prod);  // Return new constant node
        }
        else if (node->left->type == CONST && node->left->value == 0) {  // If left operand is zero
            FreeTree(node->left);  // Free left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return NewConst(0);  // Return zero
        }
        else if (node->right->type == CONST && node->right->value == 0) {  // If right operand is zero
            FreeTree(node->left);  // Free left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return NewConst(0);  // Return zero
        }
        else if (node->left->type == CONST && node->left->value == 1) {  // If left operand is one
            Node *ret = node->right;  // Return right operand
            FreeTree(node->left);  // Free left operand
            free(node);  // Free current node
            return ret;  // Return right operand
        }
        else if (node->right->type == CONST && node->right->value == 1) {  // If right operand is one
            Node *ret = node->left;  // Return left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return ret;  // Return left operand
        }
        return node;  // Return the node
    }
    else if (node->type == DIV) {  // If node is division
        node->left = Simplify(node->left);  // Simplify left operand
        node->right = Simplify(node->right);  // Simplify right operand
        if (node->left->type == CONST && node->right->type == CONST) {  // If both operands are constants
            int numerator = node->left->value, denominator = node->right->value;  // Get numerator and denominator
            if (denominator != 0 && numerator % denominator == 0) {  // If division is exact
                int quotient = numerator / denominator;  // Calculate quotient
                FreeTree(node->left);  // Free left operand
                FreeTree(node->right);  // Free right operand
                free(node);  // Free current node
                return NewConst(quotient);  // Return new constant node
            }
        }
        else if (node->left->type == CONST && node->left->value == 0) {  // If numerator is zero
            FreeTree(node->left);  // Free left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return NewConst(0);  // Return zero
        }
        else if (node->right->type == CONST && node->right->value == 1) {  // If denominator is one
            Node *ret = node->left;  // Return numerator
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return ret;  // Return numerator
        }
        else if (EqualNode(node->left, node->right)) {  // If numerator and denominator are equal
            FreeTree(node->left);  // Free left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return NewConst(1);  // Return one
        }
        return node;  // Return the node
    }
    else if (node->type == POW) {  // If node is a power
        node->left = Simplify(node->left);  // Simplify base
        node->right = Simplify(node->right);  // Simplify exponent
        if (node->left->type == CONST && node->right->type == CONST) {  // If both operands are constants
            int base = node->left->value, exponent = node->right->value, power = 1;  // Get base and exponent
            for (int i = 0; i < exponent; i++) {  // Calculate power
                power *= base;
            }
            FreeTree(node->left);  // Free left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return NewConst(power);  // Return new constant node
        }
        else if (node->right->type == CONST && node->right->value == 0) {  // If exponent is zero
            FreeTree(node->left);  // Free left operand
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return NewConst(1);  // Return one
        }
        else if (node->right->type == CONST && node->right->value == 1) {  // If exponent is one
            Node *ret = node->left;  // Return base
            FreeTree(node->right);  // Free right operand
            free(node);  // Free current node
            return ret;  // Return base
        }
        return node;  // Return the node
    }
    else {  // If node is a function
        if (node->left != NULL) {  // If left operand exists
            node->left = Simplify(node->left);  // Simplify left operand
        }
        if (node->right != NULL) {  // If right operand exists
            node->right = Simplify(node->right);  // Simplify right operand
        }
        return node;  // Return the node
    }
}

/*Output*/

int Precedence(const Node *node) {  // Function to determine the precedence of operators
    if (node == NULL) {  // If node is null, return 0
        return 0;
    }
    switch (node->type) {  // Determine precedence based on node type
        case CONST:
        case VAR:
        case LN:
        case LOG:
        case COS:
        case SIN:
        case TAN:
        case EXP:
            return 4;  // Highest precedence for constants, variables, and functions
        case POW:
            return 3;  // Precedence for power operation
        case MUL:
        case DIV:
            return 2;  // Precedence for multiplication and division
        case ADD:
        case SUB:
            return 1;  // Lowest precedence for addition and subtraction
        default:
            return 0;  // Default precedence
    }
}

void Output(const Node *node, int prtprcd) {  // Function to output the expression
    if (node == NULL) {  // If node is null, return
        return;
    }
    int crtprcd = Precedence(node);  // Get current precedence
    if (crtprcd < prtprcd) {  // If current precedence is less than parent precedence
        printf("(");  // Output opening parenthesis
    }
    switch (node->type) {  // Output based on node type
        case CONST:
            printf("%d", node->value);  // Output constant value
            break;
        case VAR:
            printf("%s", node->var);  // Output variable name
            break;
        case LN:
            printf("ln(");  // Output ln function
            Output(node->left, 0);  // Output argument
            printf(")");  // Output closing parenthesis
            break;
        case LOG:
            printf("log(");  // Output log function
            Output(node->left, 0);  // Output first argument
            printf(",");  // Output comma
            Output(node->right, 0);  // Output second argument
            printf(")");  // Output closing parenthesis
            break;
        case COS:
            printf("cos(");  // Output cos function
            Output(node->left, 0);  // Output argument
            printf(")");  // Output closing parenthesis
            break;
        case SIN:
            printf("sin(");  // Output sin function
            Output(node->left, 0);  // Output argument
            printf(")");  // Output closing parenthesis
            break;
        case TAN:
            printf("tan(");  // Output tan function
            Output(node->left, 0);  // Output argument
            printf(")");  // Output closing parenthesis
            break;
        case EXP:
            printf("exp(");  // Output exp function
            Output(node->left, 0);  // Output argument
            printf(")");  // Output closing parenthesis
            break;
        case POW:
            printf("pow(");  // Output pow function
            Output(node->left, 0);  // Output base
            printf(",");  // Output comma
            Output(node->right, 0);  // Output exponent
            printf(")");  // Output closing parenthesis
            break;
        case MUL:
            Output(node->left, crtprcd);  // Output left operand
            printf("*");  // Output multiplication operator
            Output(node->right, crtprcd);  // Output right operand
            break;
        case DIV:
            Output(node->left, crtprcd);  // Output numerator
            printf("/");  // Output division operator
            Output(node->right, crtprcd + 1);  // Output denominator
            break;
        case ADD:
            Output(node->left, crtprcd);  // Output left operand
            printf("+");  // Output addition operator
            Output(node->right, crtprcd);  // Output right operand
            break;
        case SUB:
            Output(node->left, crtprcd);  // Output left operand
            printf("-");  // Output subtraction operator
            Output(node->right, crtprcd + 1);  // Output right operand
            break;
        default:
            break;
    }
    if (crtprcd < prtprcd) {  // If current precedence is less than parent precedence
        printf(")");  // Output closing parenthesis
    }
    return;  // Return from function
}

int main() {
    fgets(input, sizeof(input), stdin);  // Read input from standard input
    Node *expr = ParseExpression();  // Parse the expression
    Traverse(expr, varlist, &varcount);  // Collect variables from the expression
    qsort(varlist, varcount, sizeof(char*), Compare);  // Sort variable list
    for (int i = 0; i < varcount; i++) {  // Loop through variables
        const char *v = varlist[i];  // Get variable name
        printf("%s: ",v);  // Output variable name
        Node *diff = Differentiate(expr, v);  // Differentiate expression with respect to variable
        diff = Simplify(diff);  // Simplify the differentiated expression
        Output(diff, 0);  // Output the simplified expression
        printf("\n");  // Output newline
        FreeTree(diff);  // Free the differentiated expression tree
        free(varlist[i]);  // Free the variable name
    }
    FreeTree(expr);  // Free the original expression tree
    return 0;
}