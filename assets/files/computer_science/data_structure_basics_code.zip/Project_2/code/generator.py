import os
import random

# Function to generate a random mathematical expression recursively
def generate_random_expression(variables, depth=3): # Generate a random mathematical expression with a specified depth
    if depth == 0: # If the depth reaches 0, return a random variable or constant
        return random.choice(variables + [str(random.randint(1, 10))]) # Randomly select from variables or integers

    ops = ['+', '-', '*', '/', 'pow', 'log', 'sin', 'cos', 'tan', 'exp'] # List of supported mathematical operators and functions
    op = random.choice(ops) # Randomly select an operation from the list

    if op in ['+', '-', '*', '/']:
        left = generate_random_expression(variables, depth - 1) # Recursively generate the left operand
        right = generate_random_expression(variables, depth - 1) # Recursively generate the right operand
        return f"({left}{op}{right})" # Return the expression in the form of (left op right)

    elif op == 'pow':
        base = generate_random_expression(variables, depth - 1) # Generate the base of the power expression
        exp = str(random.randint(1, 5)) # Randomly select an integer exponent between 1 and 5
        return f"pow({base},{exp})" # Return the expression in the form of pow(base, exp)

    elif op == 'log':
        base = generate_random_expression(variables, 1) # Generate a simple base expression with depth 1
        arg = generate_random_expression(variables, depth - 1) # Generate the logarithm argument
        return f"log({base},{arg})" # Return the expression in the form of log(base, arg)

    else: # For other unary functions like 'sin', 'cos', 'tan', and 'exp'
        arg = generate_random_expression(variables, depth - 1) # Generate the function argument recursively
        return f"{op}({arg})" # Return the expression in the form of op(arg)

input_dir = "../benchmark/input/random/"

os.makedirs(input_dir, exist_ok=True) # Ensure the output directory exists, and create it if not

variables = ["x", "y", "z", "a", "b", "c", "d", "xx", "xy"]

num_expressions = 10 # Specify how many random expressions to generate

for i in range(1, num_expressions + 1): # Loop through the desired number of random expressions
    expr = generate_random_expression(variables) # Generate a random mathematical expression
    with open(os.path.join(input_dir, f"{i}.in"), "w") as f: # Open a new file in the specified directory for writing
        f.write(expr + "\n") # Write the generated expression to the file and add a newline character

# print("Random test expressions have been generated and saved to '../benchmark/input/random/'")