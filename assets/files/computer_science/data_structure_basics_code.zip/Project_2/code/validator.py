import os
import subprocess
import sympy as sp
import random

def parse_c_output(output): # Parses the output from the C program to extract derivatives
    derivatives = {} # Dictionary to store variable-derivative pairs
    lines = output.strip().split("\n") # Split the output into lines and remove leading/trailing whitespace
    for line in lines: # Iterate through each line of output
        if ":" in line: # Check if the line contains a colon
            var, expr = line.split(":", 1) # Split the line into variable and expression
            derivatives[var.strip()] = expr.strip() # Store the variable and corresponding expression in the dictionary
    return derivatives # Return the dictionary containing all parsed derivatives

def call_c_derivative_program(expression): # Executes the C program to compute the derivative of a given expression
    process = subprocess.run(["./autograd.exe"], # Run the C executable "autograd.exe"
                             input=expression, # Provide the input expression to the C program
                             text=True, # Enable text mode for easier handling of string input/output
                             capture_output=True) # Capture the output from the C program
    return process.stdout.strip() # Return the standard output after stripping leading/trailing whitespace

def adjust_precision(value, reference, tolerance): # Adjusts the precision to handle floating-point discrepancies
    def inner_adjust(v, r): # Nested function to perform precision adjustment
        return v if abs(v - r) < tolerance else r # If the difference is within tolerance, return original; otherwise, adjust
    return inner_adjust(value, reference) if value is not None else reference # Ensure adjustment only if the value is valid

def validate_derivative(expr_str, c_derivatives, variables, epsilon=1e-6): # Validates derivatives by comparing C program output to SymPy results
    expr = sp.sympify(expr_str, evaluate=False) # Parse the input expression into a SymPy object without automatic evaluation

    point = {var: random.randint(1, 10) for var in variables} # Generate random integer values (1 to 10) for each variable

    sympy_derivatives = {str(var): sp.diff(expr, var).doit() for var in variables} # Compute analytical derivatives using SymPy

    results = {} # Store validation results for each variable
    all_correct = True # Flag to track overall correctness

    for var, sympy_deriv in sympy_derivatives.items(): # Iterate through each computed derivative
        if var in c_derivatives: # Ensure the variable exists in the C program output
            c_deriv_expr = sp.sympify(c_derivatives[var], evaluate=False) # Convert the C program's derivative to a SymPy expression

            sympy_value = sympy_deriv.evalf(subs=point) # Evaluate the SymPy derivative at the random point
            c_value = c_deriv_expr.evalf(subs=point) # Evaluate the C program derivative at the same random point

            sympy_value = adjust_precision(sympy_value, c_value, epsilon) # Adjust precision to account for floating-point errors

            correct = abs(sympy_value - c_value) < epsilon # Compare both evaluated derivatives within the tolerance

            results[var] = { # Store the validation results for the current variable
                "c_expr": c_derivatives[var], # Store the derivative expression from the C program
                "sympy_expr": str(sympy_deriv), # Store the SymPy-generated derivative expression
                "point": point, # Store the random point used for evaluation
                "c_value": c_value, # Store the evaluated value from the C program
                "sympy_value": sympy_value, # Store the evaluated value from SymPy
                "is_correct": correct # Store whether the comparison was successful
            }

            if not correct: # If any comparison fails, mark the entire validation as incorrect
                all_correct = False

    return results, all_correct # Return the detailed results and the overall correctness flag

# Validate "sample" dataset with extended variables
input_dir = "../benchmark/input/sample/"
output_dir = "../benchmark/output/sample/"
result_file = "../benchmark/result/sample.txt"

os.makedirs(output_dir, exist_ok=True) # Ensure the output directory exists, create it if necessary
os.makedirs(os.path.dirname(result_file), exist_ok=True) # Ensure the result directory exists, create if necessary

with open(result_file, "w") as log_file: # Open the result log file in write mode
    log_file.write("Derivative Validation Results (sample)\n") # Write a header for the log file
    log_file.write("-" * 40 + "\n") # Add a separator for clarity

    for i in range(1, 7): # Loop through sample dataset
        input_file = os.path.join(input_dir, f"{i}.in") # Construct the input file path
        output_file = os.path.join(output_dir, f"{i}.out") # Construct the output file path

        with open(input_file, "r") as f: # Open the current input file
            expr = f.readline().strip() # Read the input expression and strip whitespace

        c_output = call_c_derivative_program(expr) # Call the C program and get its output

        c_derivatives = parse_c_output(c_output) # Parse the output of the C program to extract derivatives

        results, is_all_correct = validate_derivative(expr, c_derivatives, ["x", "y", "z", "a", "b", "c", "d", "xx", "xy"]) # Validate the derivatives

        with open(output_file, "w") as f: # Open the corresponding output file to save the results
            f.write(f"Input Expression: {expr}\n")
            f.write("-" * 40 + "\n")

            for var, info in results.items(): # Iterate through the validation results for each variable
                f.write(f"Variable: {var}\n")
                f.write(f"C Output Expression: {info['c_expr']}\n")
                f.write(f"SymPy Expression: {info['sympy_expr']}\n")
                f.write(f"Random Point: {info['point']}\n")
                f.write(f"C Output Value: {info['c_value']}\n")
                f.write(f"SymPy Value: {info['sympy_value']}\n")
                f.write(f"Correct: {info['is_correct']}\n")
                f.write("-" * 40 + "\n")
                
        log_file.write(f"Test Case {i}: {'PASSED' if is_all_correct else 'FAILED'}\n") 

    log_file.write("-" * 40 + "\n")
    log_file.write("Validation Process Completed\n")

# print("Sample test results have been saved to '../benchmark/result/sample.txt'")

# Validate "random" dataset with extended variables
input_dir = "../benchmark/input/random/"
output_dir = "../benchmark/output/random/"
result_file = "../benchmark/result/random.txt"

os.makedirs(output_dir, exist_ok=True) # Ensure the output directory exists, create it if necessary
os.makedirs(os.path.dirname(result_file), exist_ok=True) # Ensure the result directory exists, create if necessary

with open(result_file, "w") as log_file: # Open the result log file in write mode
    log_file.write("Derivative Validation Results (random)\n") # Write a header for the log file
    log_file.write("-" * 40 + "\n") # Add a separator for clarity

    for i in range(1, 11): # Loop through random dataset
        input_file = os.path.join(input_dir, f"{i}.in") # Construct the input file path
        output_file = os.path.join(output_dir, f"{i}.out") # Construct the output file path

        with open(input_file, "r") as f: # Open the current input file
            expr = f.readline().strip() # Read the input expression and strip whitespace

        c_output = call_c_derivative_program(expr) # Call the C program and get its output

        c_derivatives = parse_c_output(c_output) # Parse the output of the C program to extract derivatives

        results, is_all_correct = validate_derivative(expr, c_derivatives, ["x", "y", "z", "a", "b", "c", "d", "xx", "xy"]) # Validate the derivatives

        with open(output_file, "w") as f: # Open the corresponding output file to save the results
            f.write(f"Input Expression: {expr}\n")
            f.write("-" * 40 + "\n")

            for var, info in results.items(): # Iterate through the validation results for each variable
                f.write(f"Variable: {var}\n")
                f.write(f"C Output Expression: {info['c_expr']}\n")
                f.write(f"SymPy Expression: {info['sympy_expr']}\n")
                f.write(f"Random Point: {info['point']}\n")
                f.write(f"C Output Value: {info['c_value']}\n")
                f.write(f"SymPy Value: {info['sympy_value']}\n")
                f.write(f"Correct: {info['is_correct']}\n")
                f.write("-" * 40 + "\n")

        log_file.write(f"Test Case {i}: {'PASSED' if is_all_correct else 'FAILED'}\n")                       

    log_file.write("-" * 40 + "\n")
    log_file.write("Validation Process Completed\n")

# print("Random test results have been saved to '../benchmark/result/random.txt'")