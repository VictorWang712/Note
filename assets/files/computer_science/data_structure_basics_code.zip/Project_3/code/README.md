# README

This directory contains four code files: `trans.c`, `reference.c`, `generator.py` and `validator.py`.

- `trans.c` is the core code of this project, designed to solve the project's problem.
- `reference.c` is the reference program used for correctness verification.
- `generator.py` is a random generator for test data.
- `validator.py` is the correctness validator.

I provide two methods for reproducing my experimental results on your local machine. Please note that both approaches are **OPTIONAL**! The method I recommend is solely intended to make your local reproduction more convenient, and is **by no means mandatory**! If you prefer not to use Python, you may adopt the "manual" approach instead. This alternative method is specifically provided for readers who only have a C language compiler and are only familiar with C-related compilation methods.

## Automatic (Recommended)

### Usage

I highly recommend using the automated script for efficient verification.

First, ensure that your computer has Python version 3.12 or above installed. If not, you can download and install it from the [official Python download page](https://www.python.org/downloads/).

After installing Python, You can sequentially execute `generator.py` to generate input data, then run `validator.py` to obtain corresponding outputs and correctness evaluation results. You can do this by entering the following commands in your terminal:

```bat
python generator.py
python validator.py
```

### Successful Execution

If, after executing Python files and waiting for a while (which may take some time), you see no error messages in the command line, this indicates that the automated verification script has executed successfully.

At this point, you can check the generated content in the `benchmark` directory:

- In the `output` directory, the files represent the output from `trans.c` corresponding to the inputs from the `input` directory.
- In the `expected` directory, the files represent the output from `reference.c` corresponding to the inputs from the `input` directory.
- In the `result.txt`, you can verify whether the program produces correct outputs for every input.

Furthermore, you can repeat the above operations multiple times. After each execution, you will notice that all files in the `benchmark` directory, will be updated with the results of the new random test.

It is worth mentioning that before your first execution of the automated script, the above folders should already contain results from a pre-generated random test. This pre-generated result is provided to facilitate your inspection. These contents will be overwritten after your first execution of Python files.

### Execution Failure

If the command line output enters an infinite loop or reports other errors after executing Python files, unfortunately, the automated script has failed.

In most cases (if not always), this situation arises due to issues with your Python installation or environment configuration. This program has been successfully tested on multiple devices with different system versions and Python versions, so please trust that the problem does not lie in the program itself.

In this case, please carefully follow the instructions above to reconfigure your environment. Regrettably, due to anonymization requirements, you cannot contact me for assistance, although I am willing to help. If you are still unable to run the script successfully, you may proceed with the manual method described below.

## Manual

Ensure that your computer has a GCC compiler supporting the C99 standard.

You can compile the program by entering the following command in the terminal:

```bat
gcc trans.c -o trans
```

Then, you can run the program by entering:

```bat
.\trans.exe
```

You may manually input valid data via the command line. Please strictly follow the expression format specified in the project requirements.

For your convenience, I have provided 11 sample test cases in the `benchmark\input` directory. These cases cover all complex scenarios and are representative. You can use them by simply copying and pasting.

Regarding output validation, as automated numerical verification is unavailable, you will need to manually verify the correctness of the outputs.
