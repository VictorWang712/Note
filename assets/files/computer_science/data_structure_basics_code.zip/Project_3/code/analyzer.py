import os

output_dir = "../benchmark/output"

print("Analyzing output files...\n")
print(f"{'Case':<6} {'Queries':<10} {'None Count':<12} {'None Ratio':<12} {'Avg Hubs (non-None)':<25}")

for i in range(1, 11):
    filename = os.path.join(output_dir, f"{i}.out")
    if not os.path.exists(filename):
        print(f"{i:<6} File not found.")
        continue

    total_queries = 0
    none_count = 0
    hub_counts = []

    with open(filename, "r") as f:
        for line in f:
            total_queries += 1
            line = line.strip()
            if line == "None":
                none_count += 1
            else:
                hub_count = len(line.split())
                hub_counts.append(hub_count)

    avg_hubs = sum(hub_counts) / len(hub_counts) if hub_counts else 0
    none_ratio = none_count / total_queries if total_queries else 0

    print(f"{i:<6} {total_queries:<10} {none_count:<12} {none_ratio:<12.2%} {avg_hubs:<25.2f}")

print("\nAnalysis complete.")
