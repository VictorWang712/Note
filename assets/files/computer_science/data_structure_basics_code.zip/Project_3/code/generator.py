import os
import random

output_dir = "../benchmark/input"  # Directory to store generated input files
os.makedirs(output_dir, exist_ok=True)  # Create directory if not exists

cases = [  # Test case parameters: (nodes, edges, k-threshold, test queries)
    (5, 6, 2, 3),
    (10, 15, 2, 5),
    (20, 40, 2, 10),
    (50, 100, 3, 30),
    (100, 300, 3, 50),
    (150, 500, 3, 80),
    (200, 800, 4, 100),
    (300, 1200, 4, 200),
    (500, 2000, 5, 500),
    (500, 3000, 5, 500),
]

def generate_connected_graph(n, m):  # Generate a connected graph with exactly m edges
    edges = set()  # Store unique edges
    used = set()  # Track used edges to avoid duplicates
    parents = list(range(n))  # Union-Find data structure for connectivity

    def find(x):  # Find root with path compression
        while x != parents[x]:
            parents[x] = parents[parents[x]]
            x = parents[x]
        return x

    def union(x, y):  # Union two sets
        px, py = find(x), find(y)
        if px != py:
            parents[px] = py
            return True
        return False

    while len(edges) < n - 1:  # Build minimum spanning tree for connectivity
        u, v = random.sample(range(n), 2)
        if (u, v) not in used and (v, u) not in used and union(u, v):
            w = random.randint(1, 10)
            edges.add((u, v, w))
            used.add((u, v))
            used.add((v, u))

    while len(edges) < m:  # Add remaining edges with larger weights
        u, v = random.sample(range(n), 2)
        if (u, v) not in used and (v, u) not in used:
            w = random.randint(5, 100)  # Longer weights to avoid being in shortest paths
            edges.add((u, v, w))
            used.add((u, v))
            used.add((v, u))
    return list(edges)

def construct_hub_structure(n, k, hub_count=3, sources_per_hub=5, targets_per_hub=5):  # Create hub-centric paths
    edges = set()  # Store generated hub-related edges
    used = set()  # Track used node pairs
    hubs = random.sample(range(n), min(hub_count, n))  # Select hub nodes

    src_pool = set()  # Collection of source nodes
    dst_pool = set()  # Collection of target nodes
    available = set(range(n)) - set(hubs)  # Non-hub nodes

    for hub in hubs:  # Create paths through each hub
        sp = min(sources_per_hub, len(available))  # Limit source count
        sources = random.sample(list(available), sp)
        available -= set(sources)

        tp = min(targets_per_hub, len(available))  # Limit target count
        targets = random.sample(list(available), tp)
        available -= set(targets)

        for s in sources:  # Connect sources to hub via intermediates
            mid = random.randint(0, n - 1)
            if mid in [s, hub]: continue
            edges.add((s, mid, 1))  # Low weight to enforce shortest paths
            edges.add((mid, hub, 1))
            used.update([(s, mid), (mid, hub), (mid, s), (hub, mid)])
            src_pool.add(s)

        for t in targets:  # Connect hub to targets via intermediates
            mid = random.randint(0, n - 1)
            if mid in [t, hub]: continue
            edges.add((hub, mid, 1))
            edges.add((mid, t, 1))
            used.update([(hub, mid), (mid, t), (mid, hub), (t, mid)])
            dst_pool.add(t)

    return list(edges), list(src_pool), list(dst_pool), hubs

for idx, (n, m, k, T) in enumerate(cases):  # Process each test case
    filename = os.path.join(output_dir, f"{idx + 1}.in")  # Create input filename
    with open(filename, "w") as f:  # Write data to file
        hub_edges, sources, targets, hub_list = construct_hub_structure(n, k)  # Generate hub structure
        hub_edge_count = len(hub_edges)

        remaining_edges = generate_connected_graph(n, m - hub_edge_count)  # Generate remaining edges

        f.write(f"{n} {m} {k}\n")  # Write graph header
        all_edges = hub_edges + remaining_edges
        for u, v, w in all_edges:  # Write all edges
            f.write(f"{u} {v} {w}\n")

        f.write(f"{T}\n")  # Write test query count
        queries_written = 0

        for _ in range(min(T, len(sources) * len(targets))):  # Generate hub-related queries
            s = random.choice(sources)
            t = random.choice(targets)
            if s != t:
                f.write(f"{s} {t}\n")
                queries_written += 1

        while queries_written < T:  # Fill remaining with random queries
            s = random.randint(0, n - 1)
            t = random.randint(0, n - 1)
            if s != t:
                f.write(f"{s} {t}\n")
                queries_written += 1