#include <stdio.h>
#include <string.h>
#define N 510
#define INF 0x3f3f3f3f

int n, m, k, T;
int graph[N][N], dist[N][N], path_count[N][N], next_nodes[N][N];

void Floyd() {  // Floyd-Warshall algorithm to compute all-pairs shortest paths
    for (int i = 0; i < n; i++) {  // Initialize distance matrix
        for (int j = 0; j < n; j++) {  
            dist[i][j] = (i == j) ? 0 : graph[i][j];  // Set diagonal to 0, others from adjacency matrix
        }
    }
    for (int k = 0; k < n; k++) {  // Intermediate node iteration
        for (int i = 0; i < n; i++) {  // Source node iteration
            for (int j = 0; j < n; j++) {  // Target node iteration
                if (dist[i][k] + dist[k][j] < dist[i][j]) {  // Relaxation condition
                    dist[i][j] = dist[i][k] + dist[k][j];  // Update shortest path distance
                }
            }
        }
    }
    return;
}

int DFS(int u, int t, int *visited) {  // Recursive DFS to count paths from u to t
    if (u == t) {  // Base case: reached target node
        return 1;
    }
    if (path_count[u][t] != -1) {  // Return cached value if available
        return path_count[u][t];
    }
    int cnt = 0;  // Counter for valid paths
    visited[u] = 1;  // Mark current node as visited
    for (int v = 0; v < n; v++) {  // Iterate through all nodes
        if (v == u || graph[u][v] == INF) {  // Skip self and invalid edges
            continue;
        }
        if (dist[u][t] == graph[u][v] + dist[v][t]) {  // Check if edge is part of a shortest path
            cnt += DFS(v, t, visited);  // Accumulate path count recursively
        }
    }
    visited[u] = 0;  // Unmark node for backtracking
    path_count[u][t] = cnt;  // Cache the computed path count
    return cnt;
}

int Judge(int s, int t, int mid) {  // Check if mid is on any shortest path from s to t
    if (mid == s || mid == t) {  // Mid cannot be source or destination
        return 0;
    }
    return dist[s][t] == dist[s][mid] + dist[mid][t];  // Verify triangle equality for shortest paths
}

int main() {
    scanf("%d %d %d", &n, &m, &k);  // Read nodes, edges, threshold
    for (int i = 0; i < n; i++) {  // Initialize adjacency matrix
        for (int j = 0; j < n; j++) {  
            graph[i][j] = INF;  // Set all edges to INF initially
        }
    }
    for (int i = 0; i < m; i++) {  // Read edge data
        int u, v, w;  
        scanf("%d %d %d", &u, &v, &w);  // Input edge endpoints and weight
        graph[u][v] = graph[v][u] = w;  // Update adjacency matrix (undirected)
    }
    Floyd();  // Compute all-pairs shortest paths
    scanf("%d", &T);  // Read number of test cases
    for (int q = 0; q < T; q++) {  // Process each test case
        int s, t;  
        scanf("%d %d", &s, &t);  // Read source and target
        memset(path_count, -1, sizeof(path_count));  // Reset path count cache
        int visited[N] = {0};  // Initialize visited array
        int total_paths = DFS(s, t, visited);  // Calculate total shortest paths
        int hubs[N], hub_count = 0;  // Array to store qualifying hubs
        for (int mid = 0; mid < n; mid++) {  // Check all nodes as potential hubs
            if (!Judge(s, t, mid)) {  // Skip if mid is not on any shortest path
                continue;
            }
            memset(path_count, -1, sizeof(path_count));  // Reset path count cache
            int ps = DFS(s, mid, visited);  // Paths from source to mid
            memset(path_count, -1, sizeof(path_count));  // Reset cache again
            int pt = DFS(mid, t, visited);  // Paths from mid to target
            if (ps * pt >= k) {  // Check if product meets threshold
                hubs[hub_count++] = mid;  // Record qualifying hub
            }
        }
        if (hub_count == 0) {  // No hubs found
            printf("None\n");  
        }
        else {  // Print hubs
            for (int i = 0; i < hub_count; i++) {  
                if (i > 0) {  // Format with spaces
                    printf(" ");  
                }
                printf("%d", hubs[i]);  // Output hub ID
            }
            printf("\n");  
        }
    }
    return 0;  
}