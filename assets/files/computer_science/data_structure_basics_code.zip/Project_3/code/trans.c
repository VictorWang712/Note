#include <stdio.h>
#include <string.h>
#define N 510
#define INF 0x3f3f3f3f

int n, m, k, t, s, d, len, found;
int graph[N][N], dist[N], vis[N], hub[N], path[N], cnt[N], rec[N], frm[N][N];

void Dijkstra(int s) {  // Dijkstra's algorithm to find shortest paths
    for (int i = 0; i < n; i++) {  // Initialize arrays for all nodes
        dist[i] = INF, vis[i] = 0, hub[i] = 0, cnt[i] = 0; // Reset distance, visited flags, hub counts
    }
    dist[s] = 0, path[s] = 1;  // Source node distance=0, path count initialized
    for (int i = 0; i < n; i++) {  // Process all nodes
        int u = -1, min = INF;     // Track node with minimal tentative distance
        for (int j = 0; j < n; j++) {  // Find unvisited node with smallest distance
            if (vis[j] == 0 && dist[j] < min) {  // Check unvisited and distance condition
                u = j, min = dist[j];  // Update selected node
            }
        }
        if (u == -1) {  // No reachable nodes left
            break;
        }
        vis[u] = 1;  // Mark node as visited
        for (int j = 0; j < n; j++) {  // Update neighbors of selected node
            int v = j;  // Current neighbor index
            if (graph[u][v] != INF && vis[v] == 0) {  // Check valid edge and unvisited neighbor
                if (dist[u] + graph[u][v] < dist[v]) {  // Found shorter path
                    dist[v] = dist[u] + graph[u][v];  // Update shortest distance
                    path[v] = path[u];  // Reset path count to current node's count
                    cnt[v] = 0;  // Clear predecessor count
                    frm[v][cnt[v]] = u, cnt[v]++;  // Record predecessor
                }
                else if (dist[u] + graph[u][v] == dist[v]) {  // Equal distance path found
                    path[v] += path[u];  // Accumulate path count
                    frm[v][cnt[v]] = u, cnt[v]++;  // Add another predecessor
                }
            }
        }
    }
    return;
}

void DFS(int s, int cur) {  // Depth-First Search to trace all shortest paths
    if (cur == s) {  // Base case: reached source node
        for (int i = 1; i < len - 1; i++) {  // Exclude endpoints in path
            hub[rec[i]]++;  // Increment hub count for intermediate nodes
        }
        return;
    }
    for (int i = 0; i < cnt[cur]; i++) {  // Iterate through predecessors
        rec[len] = frm[cur][i], len++;  // Record current predecessor
        DFS(s, frm[cur][i]);  // Recursively backtrack path
        len--;  // Remove last node when backtracking
    }
}

int main()
{
    scanf("%d %d %d", &n, &m, &k);  // Read nodes, edges, hub threshold
    for (int i = 0; i < n; i++) {  // Initialize adjacency matrix
        for (int j = 0; j < n; j++) {  
            if (i != j) {  
                graph[i][j] = INF;  // Set non-diagonal entries to INF
            }
        }
    }
    for (int i = 0; i < m; i++) {  // Read edge data
        int u, v, w;  
        scanf("%d %d %d", &u, &v, &w);  // Input edge endpoints and weight
        graph[u][v] = w, graph[v][u] = w;  // Undirected graph setup
    }
    scanf("%d", &t);  // Read number of test cases
    for (int i = 0; i < t; i++) {  // Process each test case
        scanf("%d %d", &s, &d);  // Read source and destination
        if (s == d) {  // Handle trivial case
            printf("None\n");  
            continue;
        }
        memset(hub, 0, sizeof(hub));  // Reset hub counter array
        Dijkstra(s);  // Compute shortest paths from source
        if (dist[d] == INF) {  // Destination unreachable
            printf("None\n");  
            continue;
        }
        len = 0;  // Initialize path recording index
        rec[len] = d, len++;  // Start path with destination node
        DFS(s, d);  // Trace paths to count intermediate hubs
        found = 0;  // Flag to check output formatting
        for (int i = 0; i < n; i++) {  // Iterate all nodes
            if (i != s && i != d && hub[i] >= k) {  // Check hub condition
                if (found == 1) {  // Handle space between outputs
                    printf(" ");  
                }
                else {  
                    found = 1;  
                }
                printf("%d", i);  // Print qualifying hub ID
            }
        }
        if (found == 0) {  // No hubs met threshold
            printf("None");  
        }
        printf("\n");  
    }
    return 0;  
}