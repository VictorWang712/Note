import os
import subprocess

# Path configurations
code_dir = "../code"  # Directory containing source code
benchmark_dir = "../benchmark"  # Root benchmark directory
input_dir = "../benchmark/input"  # Input test cases directory
output_dir = "../benchmark/output"  # Program output directory
expected_dir = "../benchmark/expected"  # Expected output directory
result_file = "../benchmark/result.txt"  # Validation result log

# Create output directories if missing
os.makedirs(output_dir, exist_ok=True)  # Ensure output directory exists
os.makedirs(expected_dir, exist_ok=True)  # Ensure expected directory exists

def compile_code(source_file, output_file):  # Compile C source to executable
    print(f"Compiling {source_file} to {output_file}...")  # Log compilation start
    result = subprocess.run(  # Execute GCC compiler
        ["gcc", "-o", output_file, source_file],  # Compiler command
        cwd=code_dir, stdout=subprocess.PIPE, stderr=subprocess.PIPE  # Set working dir
    )
    if result.returncode != 0:  # Handle compilation failure
        print(f"Compilation of {source_file} failed!")  # Error message
        print(result.stderr.decode())  # Print compiler errors
        exit(1)  # Terminate script
    print(f"Compilation of {source_file} succeeded.")  # Success message

def run_program(executable, input_file, output_file):  # Execute compiled program
    print(f"Running {executable} with input {input_file}...")  # Log execution start
    with open(input_file, "r") as input_f, open(output_file, "w") as output_f:  # Open I/O files
        result = subprocess.run(  # Run the executable
            [f"./{executable}"],  # Program to execute
            cwd=code_dir, stdin=input_f, stdout=output_f, stderr=subprocess.PIPE  # I/O redirection
        )
        if result.returncode != 0:  # Handle runtime error
            print(f"Running {executable} failed!")  # Error message
            print(result.stderr.decode())  # Print runtime errors
            exit(1)  # Terminate script
    print(f"Running {executable} completed.")  # Success message

def compare_files(output_file, expected_file):  # Compare two files line-by-line
    with open(output_file, "r") as f1, open(expected_file, "r") as f2:  # Open both files
        lines1 = [line.strip() for line in f1.readlines()]  # Read and clean output lines
        lines2 = [line.strip() for line in f2.readlines()]  # Read and clean expected lines
    
    max_len = max(len(lines1), len(lines2))  # Determine maximum line count
    diffs = []  # Store line differences

    for i in range(max_len):  # Compare each line
        if i >= len(lines1):  # Missing line in output
            diffs.append(f"Line {i+1}: Missing in output, expected: {lines2[i]}")
        elif i >= len(lines2):  # Extra line in output
            diffs.append(f"Line {i+1}: Extra line in output: {lines1[i]}")
        elif lines1[i] != lines2[i]:  # Content mismatch
            diffs.append(f"Line {i+1}:\n  Output  : {lines1[i]}\n  Expected: {lines2[i]}")
    
    return diffs  # Return list of discrepancies

def main():  # Main validation workflow
    print("Starting validation...\n")  # Init message

    with open(result_file, "w") as result_log:  # Open result log file

        # Compile both implementations
        compile_code("trans.c", "trans.exe")  # Compile user's solution
        compile_code("reference.c", "reference.exe")  # Compile reference solution

        # Process all test cases (0-10)
        for i in range(0, 11):  # Iterate through test indices
            input_file = os.path.join(input_dir, f"{i}.in")  # Input test path
            output_file = os.path.join(output_dir, f"{i}.out")  # Program output path
            expected_file = os.path.join(expected_dir, f"{i}.ans")  # Expected output path

            if not os.path.exists(input_file):  # Handle missing input
                msg = f"[{i}] Missing input file: {input_file}\n"
                print(msg.strip())
                result_log.write(msg)
                continue

            # Generate expected output from reference
            run_program("reference.exe", input_file, expected_file)  # Run reference
            run_program("trans.exe", input_file, output_file)  # Run user's code

            diffs = compare_files(output_file, expected_file)  # Compare results
            if not diffs:  # Test passed
                msg = f"[{i}] Passed\n"
                print(msg.strip())
                result_log.write(msg)
            else:  # Test failed
                msg = f"[{i}] Difference found ({len(diffs)} diffs):\n"
                print(msg.strip())
                result_log.write(msg)
                for diff in diffs[:5]:  # Show first 5 diffs
                    print("   " + diff)
                    result_log.write("   " + diff + "\n")
                if len(diffs) > 5:  # Truncate long diffs
                    summary = f"   ...and {len(diffs) - 5} more differences.\n"
                    print(summary.strip())
                    result_log.write(summary)

if __name__ == "__main__":  # Script entry point
    main()