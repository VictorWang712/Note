#include <stdio.h>
#define N 100010
#define M 2000010

int n, h, ans, max;
int a[N], sum[M], vis[M];

int main()
{
    scanf("%d %d", &n, &h);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < n; i++) {
        vis[a[i] + 1000000] = 1;
    }
    for (int i = 0; i <= h; i++) {
        if (vis[i] == 1) {
            sum[0]++;
        }
    }
    for (int i = 1; i <= 2000000; i++) {
        sum[i] = sum[i - 1];
        if (i + h <= 2000000) {
            if (vis[i + h] == 1) {
                sum[i]++;
            }
        }
        if (vis[i - 1] == 1) {
            sum[i]--;
        }
        if (sum[i] > max) {
            ans = i, max = sum[i];
        }
    }
    ans -= 1000000;
    printf("%d %d\n", ans, max);
    return 0;
}