#include <stdio.h>
#define N 100010
#define M 2000010

int n, h, l, r, ans, max;
int a[N];

int main()
{
    scanf("%d %d", &n, &h);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < n; i++) {
        r = i;
        while (a[l] + h < a[r]) {
            l++;
        }
        //printf("l:%d r:%d\n", l, r);
        if (r - l + 1 > max) {
            ans = a[r] - h, max = r - l + 1;
        }
    }
    printf("%d %d\n", ans, max);
    return 0;
}