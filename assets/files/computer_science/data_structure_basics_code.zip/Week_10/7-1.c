#include <stdio.h>
#include <string.h>
#define N 1010
#define M 18000
#define INF 0x3f3f3f3f

int n, m, s, t;
int hash[M], saved[M], cap[N][N], flow[N][N], pre[N], vis[N];
char sname[4], tname[4];

int Convert(char* name) {
    int raw;
    raw = (name[0] - 'A') * 26 * 26 + (name[1] - 'A') * 26 + (name[2] - 'A');
    if (saved[raw] == 0) {
        hash[raw] = m;
        m++;
        saved[raw] = 1;
    }
    return hash[raw];
}

int BFS() {
    memset(pre, -1, sizeof(pre));
    memset(vis, 0, sizeof(vis));
    int frt = 0, rear = 0;
    int queue[N];
    queue[rear] = s; rear++;
    vis[s] = 1;
    while (frt < rear) {
        int u = queue[frt]; frt++;
        for (int v = 0; v < n; v++) {
            if (vis[v] == 0 && cap[u][v] > flow[u][v]) {
                vis[v] = 1;
                pre[v] = u;
                queue[rear] = v; rear++;
                if (v == t) {
                    return 1;
                }
            }
        }
    }
    return 0;
}

int MaxFlow(int s, int t) {
    int ret = 0;
    while (BFS() == 1) {
        int inc = INF;
        for (int u = t; u != s; u = pre[u]) {
            int v = pre[u];
            if (cap[v][u] - flow[v][u] < inc) {
                inc = cap[v][u] - flow[v][u];
            }
        }
        for (int u = t; u != s; u = pre[u]) {
            int v = pre[u];
            flow[v][u] += inc;
            flow[u][v] -= inc;
        }
        ret += inc;
    }
    return ret;
}

int main()
{
    scanf("%s %s %d", sname, tname, &n);
    s = Convert(sname), t = Convert(tname);
    for (int i = 0; i < n; i++) {
        int u, v, w;
        char uname[4], vname[4];
        scanf("%s %s %d", uname, vname, &w);
        u = Convert(uname), v = Convert(vname);
        cap[u][v] = w;
    }
    printf("%d\n", MaxFlow(s, t));
    return 0;
}