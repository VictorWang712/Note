#include <stdio.h>
#include <string.h>
#define N 510
#define M 25010
#define INF 0x3f3f3f3f

int n, m, ans, scd, cnt, cpn, path;
int s[N], used[M], pre[N], vis[N], graph[N][N];

struct node {
    int u, v, w;
};

struct node edge[M];

void Sort() {
    int min, ind;
    for (int i = 0; i < m; i++) {
        min = INF; ind = -1;
        for (int j = i; j < m; j++) {
            if (min > edge[j].w) {
                ind = j;
                min = edge[j].w;
            }
        }
        struct node tmp;
        tmp.u = edge[ind].u; tmp.v = edge[ind].v; tmp.w = edge[ind].w;
        edge[ind].u = edge[i].u; edge[ind].v = edge[i].v; edge[ind].w = edge[i].w;
        edge[i].u = tmp.u; edge[i].v = tmp.v; edge[i].w = tmp.w;
    }
}

int Find(int x) {
    if (s[x] == x) {
        return x;
    }
    else {
        return s[x] = Find(s[x]);
    }
}

void Union(int a, int b) {
    s[Find(b)] = Find(a);
    return;
}

int Kruskal() {
    int ret = 0;
    for (int i = 1; i <= n; i++) {
        s[i] = i;
    }
    for (int i = 0; i < m; i++) {
        int a, b, c;
        a = edge[i].u; b = edge[i].v; c = edge[i].w;
        if (Find(a) != Find(b)) {
            ret += c;
            Union(a, b);
            cnt++;
            used[i] = 1;
            graph[a][b] = c; graph[b][a] = c;
        }
    }
    return ret;
}

void BFS(int s, int t) {
    memset(pre, -1, sizeof(pre));
    memset(vis, 0, sizeof(vis));
    int frt = 0, rear = 0;
    int queue[N];
    queue[rear] = s; rear++;
    vis[s] = 1;
    while (frt < rear) {
        int u = queue[frt]; frt++;
        for (int v = 1; v <= n; v++) {
            if (vis[v] == 0 && graph[u][v] > 0) {
                vis[v] = 1;
                pre[v] = u;
                queue[rear] = v; rear++;
                if (v == t) {
                    return;
                }
            }
        }
    }
}

int Second(int s, int t, int w) {
    int ret, max = 0;
    BFS(s, t);
    for (int u = t; u != s; u = pre[u]) {
        int v = pre[u];
        if (max < graph[u][v]) {
            max = graph[u][v];
        }
    }
    ret = ans - max + w;
    return ret;
}

int main()
{
    scanf("%d %d", &n, &m);
    for (int i = 0; i < m; i++) {
        int u, v, w;
        scanf("%d %d %d", &u, &v, &w);
        edge[i].u = u; edge[i].v = v; edge[i].w = w;
    }
    Sort();
    ans = Kruskal();
    if (cnt == n - 1) {
        printf("%d\n", ans);
        scd = INF;
        for (int i = 0; i < m; i++) {
            int a, b, c;
            a = edge[i].u; b = edge[i].v; c = edge[i].w;
            if (used[i] == 0) {
                int tmp = Second(a, b, c);
                if (scd > tmp) {
                    scd = tmp;
                }
            }
        }
        printf("%s\n", ans != scd ? "Yes" : "No");
    }
    else {
        printf("No MST\n");
        for (int i = 0; i < m; i++) {
            int a, b, c;
            a = edge[i].u; b = edge[i].v; c = edge[i].w;
            Union(a, b);
        }
        for (int i = 1; i <= n; i++) {
            if (s[i] == i) {
                cpn++;
            }
        }
        printf("%d\n", cpn);
    }
    return 0;
}