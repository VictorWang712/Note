int ind, top;
int dfn[MaxVertices], low[MaxVertices], stack[MaxVertices], vis[MaxVertices];

void Tarjan(Graph G, void (*visit)(Vertex V), int v) {
    dfn[v] = ind; low[v] = ind; ind++;
    stack[top] = v; top++;
    vis[v] = 1;
    for (PtrToVNode p = G->Array[v]; p; p = p->Next) {
        int w = p->Vert;
        if (dfn[w] == -1) {
            Tarjan(G, visit, w);
            if (low[w] < low[v]) {
                low[v] = low[w];
            }
        }
        else if (vis[w] == 1) {
            if (dfn[w] < low[v]) {
                low[v] = dfn[w];
            }
        }
    }
    if (dfn[v] == low[v]) {
        int w;
        do {
            top--; w = stack[top];
            vis[w] = 0;
            visit(w);
        } while(w != v);
        printf("\n");
    }
}

void StronglyConnectedComponents(Graph G, void (*visit)(Vertex V)) {
    for (int i = 0; i < MaxVertices; i++) {
        dfn[i] = -1;
        low[i] = -1;
    }
    for (int i = 0; i < G->NumOfVertices; i++) {
        if (dfn[i] == -1) {
            Tarjan(G, visit, i);
        }
    }
}