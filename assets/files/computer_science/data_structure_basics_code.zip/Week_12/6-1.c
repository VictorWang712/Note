void merge_pass(ElementType list[], ElementType sorted[], int N, int length) {
    int pos = 0;
    while (pos <= N - length * 2) {
        int l, r, mid, i, j, k;
        l = pos; r = pos + length * 2; mid = pos + length;
        i = l; j = mid, k = l;
        while (i < mid && j < r) {
            if (list[i] <= list[j]) {
                sorted[k] = list[i]; i++; k++;
            }
            else {
                sorted[k] = list[j]; j++; k++;
            }
        }
        while (i < mid) {
            sorted[k] = list[i]; i++; k++;
        }
        while (j < r) {
            sorted[k] = list[j]; j++; k++;
        }
        pos += length * 2;
    }
    if (pos + length < N) {
        int l, r, mid, i, j, k;
        l = pos; r = N; mid = pos + length;
        i = l; j = mid, k = l;
        while (i < mid && j < r) {
            if (list[i] <= list[j]) {
                sorted[k] = list[i]; i++; k++;
            }
            else {
                sorted[k] = list[j]; j++; k++;
            }
        }
        while (i < mid) {
            sorted[k] = list[i]; i++; k++;
        }
        while (j < r) {
            sorted[k] = list[j]; j++; k++;
        }
    }
    else {
        for (int i = pos; i < N; i++) {
            sorted[i] = list[i];
        }
    }
}