#include <stdio.h>
#define N 110

int n;
int a[N], b[N];

void Insertion_Sort() {
    int flag = 0;
    int t[N];
    for (int i = 0; i < n; i++) {
        t[i] = a[i];
    }
    for (int i = 0; i < n; i++) {
        flag = 1;
        for (int j = 0; j < n; j++) {
            if (t[j] != b[j]) {
                flag = 0;
                break;
            }
        }
        for (int j = i; j > 0; j--) {
            if (t[j] < t[j - 1]) {
                int tmp = t[j];
                t[j] = t[j - 1];
                t[j - 1] = tmp;
            }
        }
        if (flag == 1) {
            printf("Insertion Sort\n");
            for (int j = 0; j < n; j++) {
                printf("%d%c", t[j], j == n - 1 ? '\n' : ' ');
            }
            break;
        }
    }
    return;
}

void Percolate_Down(int* arr, int o, int len) {
    int p = o, c = o * 2 + 1;
    while (c <= len - 1) {
        if (c + 1 <= len - 1) {
            if (arr[c] < arr[c + 1]) {
                c++;
            }
        }
        if (arr[p] >= arr[c]) {
            return;
        }
        else {
            int tmp = arr[p];
            arr[p] = arr[c];
            arr[c] = tmp;
            p = c;
            c = p * 2 + 1;
        }
    }
    return;
}

void Heap_Sort() {
    int flag = 0;
    int t[N];
    for (int i = 0; i < n; i++) {
        t[i] = a[i];
    }
    for (int i = (n - 1) / 2; i >= 0; i--) {
        Percolate_Down(t, i, n);
    }
    for (int i = n - 1; i > 0; i--) {
        flag = 1;
        for (int j = 0; j < n; j++) {
            if (t[j] != b[j]) {
                flag = 0;
                break;
            }
        }
        int tmp = t[0];
        t[0] = t[i];
        t[i] = tmp;
        Percolate_Down(t, 0, i);        
        if (flag == 1) {
            printf("Heap_Sort\n");
            for (int j = 0; j < n; j++) {
                printf("%d%c", t[j], j == n - 1 ? '\n' : ' ');
            }
            break;
        }
    }
    return;
}

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < n; i++) {
        scanf("%d", &b[i]);
    }
    Insertion_Sort();
    Heap_Sort();
    return 0;
}