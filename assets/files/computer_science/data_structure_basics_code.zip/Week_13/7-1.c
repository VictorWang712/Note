#include <stdio.h>
#define N 1010

int n, m, cnt;
int hash[N], arr[N], ans[N], vis[N], used[N];

void Sort(int* a, int n) {
    for (int i = 1; i < n; i++) {
        int tmp = a[i], aim = 0;
        for (int j = i; j > 0; j--) {
            if (a[j - 1] <= tmp) {
                aim = j;
                break;
            }
            else {
                a[j] = a[j - 1];
            }
        }
        a[aim] = tmp;
    }
    return;
}

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &hash[i]);
        arr[i] = hash[i];
    }
    Sort(arr, n);
    m = n;
    for (int i = 0; i < n; i++) {
        if (arr[i] < 0) {
            vis[i] = 1;
            m--;
        }
    }
    /*
    printf("m:%d n:%d\n", m, n);
    for (int i = 0; i < n; i++) {
        printf("%d%c", arr[i], i == n - 1 ? '\n' : ' ');
    }
    */
    while (cnt < m) {
        for (int i = 0; i < n; i++) {
            int flag = 0;
            if (vis[i] == 0) {
                int pos = arr[i] % n;
                for (int j = 0; j < n; j++) {
                    int t = (pos + j) % n;
                    if (used[t] == 0 && hash[t] == arr[i]) {
                        ans[cnt] = arr[i]; cnt++;
                        vis[i] = 1; used[t] = 1;
                        flag = 1;
                        break;
                    }
                    if (used[t] == 0 && hash[t] != arr[i]) {
                        break;
                    }
                }
            }
            if (flag == 1) {
                break;
            }
        }
    }
    for (int i = 0; i < cnt; i++) {
        printf("%d%c", ans[i], i == cnt - 1 ? '\n' : ' ');
    }
    return 0;
}