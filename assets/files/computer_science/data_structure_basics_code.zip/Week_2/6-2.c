List Reverse(List L) {
    Position crt = L->Next, prv = NULL, nxt = NULL;
    while (crt != NULL) {
        nxt = crt->Next, crt->Next = prv, prv = crt, crt = nxt;
    }
    L->Next = prv;
    return L;
}