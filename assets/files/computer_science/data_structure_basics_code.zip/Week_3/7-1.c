#include <stdio.h>
#define N 1010

int m, n, k, size, cnt, ans;
int a[N], stack[N];

void Solve() {
    size = 0, cnt = 1, ans = 1;
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < n; i++) {
        while (cnt <= a[i]) {
            size++, stack[size] = cnt;
            if (size > m) {
                ans = 0;
                break;
            }
            cnt++;
        }
        if (ans == 0) {
            break;
        }
        if (stack[size] != a[i]) {
            ans = 0;
            break;
        }
        else {
            size--;
        }
    }
    printf("%s\n", ans == 1 ? "YES" : "NO");
    return;
}

int main()
{
    scanf("%d %d %d", &m, &n, &k);
    for (int i = 0; i < k; i++) {
        Solve();
    }
    return 0;
}