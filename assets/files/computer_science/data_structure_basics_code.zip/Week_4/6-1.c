int Isomorphic(Tree T1, Tree T2) {
    if (T1 == NULL && T2 == NULL) {
        return 1;
    }
    if (T1 == NULL || T2 == NULL) {
        return 0;
    }
    if (T1->Element != T2->Element) {
        return 0;
    }
    return (((Isomorphic(T1->Left, T2->Left) == 1) && (Isomorphic(T1->Right, T2->Right) == 1)) || ((Isomorphic(T1->Left, T2->Right) == 1) && (Isomorphic(T1->Right, T2->Left) == 1)));
}