#include <stdio.h>
#define N 40

int n, root, pstind, frt, rear, level;
int in[N], pst[N], queue[N];

struct Node {
    int val, lson, rson;
};

struct Node tree[N];

int FindIndex(int l, int r, int val) {
    for (int i = l; i <= r; i++) {
        if (in[i] == val) {
            return i;
        }
    }
    return -1;
}

int BuildTree(int l, int r) {
    if (l > r) {
        return 0;
    }
    int o = pst[pstind], oind;
    pstind--;
    oind = FindIndex(l, r, o);
    tree[o].val = o;
    tree[o].rson = BuildTree(oind + 1, r);
    tree[o].lson = BuildTree(l, oind - 1);
    return o;
}

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &in[i]);
    }
    for (int i = 0; i < n; i++) {
        scanf("%d", &pst[i]);
    }
    pstind = n - 1;
    root = BuildTree(0, n - 1);
    queue[rear] = root, rear++;
    while (frt < rear) {
        int tind = 0, tsiz = rear - frt;
        int tnode[N];
        for (int i = 0; i < tsiz; i++) {
            int f = queue[frt];
            frt++;
            tnode[tind] = f, tind++;
            if (tree[f].lson != 0) {
                queue[rear] = tree[f].lson, rear++;
            }
            if (tree[f].rson != 0) {
                queue[rear] = tree[f].rson, rear++;
            }
        }
        if (level % 2 == 0) {
            for (int i = 0, j = tsiz - 1; i < j; i++, j--) {
                int tmp = tnode[i];
                tnode[i] = tnode[j];
                tnode[j] = tmp;
            }
        }
        printf("%d", tnode[0]);
        for (int i = 1; i < tsiz; i++) {
            printf(" %d", tnode[i]);
        }
        if (frt < rear) {
            printf(" ");
        }
        level++;
    }
    return 0;
}