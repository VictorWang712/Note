void PercolateUp(int p, PriorityQueue H) {
    while (H->Elements[p] < H->Elements[p / 2]) {
        int tmp = H->Elements[p];
        H->Elements[p] = H->Elements[p / 2];
        H->Elements[p / 2] = tmp;
        p /= 2;
    }
    return;
}

void PercolateDown(int p, PriorityQueue H) {
    while (p * 2 <= H->Size) {
        int child = p * 2;
        if (H->Size >= child + 1) {
            if (H->Elements[child] > H->Elements[child + 1]) {
                child++;
            }
        }
        if (H->Elements[p] > H->Elements[child]) {
            int tmp = H->Elements[p];
            H->Elements[p] = H->Elements[child];
            H->Elements[child] = tmp;
            p = child;
        }
        else {
            break;
        }
    }
    return;
}