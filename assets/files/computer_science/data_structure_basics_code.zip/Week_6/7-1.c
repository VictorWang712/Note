#include <stdio.h>
#include <stdlib.h>
#define N 1010

int n, tot, dep, cnt;
int a[N], size[N], tree[N];

int Compare(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

void Traverse(int o, int dep) {
    if (size[dep + 1] > 0) {
        Traverse(o * 2, dep + 1);
    }
    tree[o] = a[cnt], cnt++, size[dep]--;
    if (size[dep + 1] > 0) {
        Traverse(o * 2 + 1, dep + 1);
    }
    return;
}

int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    qsort(a, n, sizeof(int), Compare);
    dep = 1, size[1] = 1, tot = 1;
    while (tot < n) {
        dep++;
        if (tot + size[dep - 1] * 2 <= n) {
            size[dep] = size[dep - 1] * 2;
        }
        else {
            size[dep] = n - tot;
        }
        tot += size[dep];
    }
    Traverse(1, 1);
    for (int i = 1; i <= n; i++) {
        printf("%d%c", tree[i], i == n ? '\n' : ' ');
    }
    return 0;
}