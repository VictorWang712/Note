#include <stdio.h>
#define N 10010

int n, k;
int p[N];

int Find(int x) {
    if (p[x] == x) {
        return x;
    }
    else {
        return p[x] = Find(p[x]);
    }
}

void Union(int x, int y) {
    p[Find(y)] = Find(x);
    return;
}

int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        p[i] = i;
    }
    while (1) {
        int a, b;
        char op;
        scanf(" %c", &op);
        if (op == 'S') {
            break;
        }
        scanf("%d %d", &a, &b);
        if (op == 'C') {
            printf("%s\n", Find(a) == Find(b) ? "yes" : "no");
        }
        else if (op == 'I') {
            Union(a, b);
        }
    }
    for (int i = 1; i <= n; i++) {
        if (p[i] == i) {
            k++;
        }
    }
    if (k == 1) {
        printf("The network is connected.\n");
    }
    else {
        printf("There are %d components.", k);
    }
    return 0;
}