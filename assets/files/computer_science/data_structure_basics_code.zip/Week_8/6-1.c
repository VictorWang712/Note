bool IsTopSeq(LGraph Graph, Vertex Seq[]) {
    int indeg[MaxVertexNum] = {0};
    for (int i = 0; i < Graph->Nv; i++) {
        PtrToAdjVNode node = Graph->G[i].FirstEdge;
        while (node != NULL) {
            indeg[node->AdjV]++;
            node = node->Next;
        }
    }
    for (int i = 0; i < Graph->Nv; i++) {
        int v = Seq[i] - 1;
        if (indeg[v] != 0) {
            return false;
        }
        PtrToAdjVNode node = Graph->G[v].FirstEdge;
        while (node != NULL) {
            indeg[node->AdjV]--;
            node = node->Next;
        }
    }
    return true;
}