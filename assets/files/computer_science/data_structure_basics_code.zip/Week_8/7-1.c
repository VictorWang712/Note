#include <stdio.h>
#include <string.h>
#define N 210

int n, m, k, d;
int graph[N][N], seq[N], vis[N];

int IsHam() {
    if (d != n + 1) {
        return 0;
    }
    if (seq[0] != seq[n]) {
        return 0;
    }
    memset(vis, 0, sizeof(vis));
    for (int i = 0; i < d - 1; i++) {
        int u = seq[i], v = seq[i + 1];
        if (graph[u][v] == 0) {
            return 0;
        }
        vis[u] = 1, vis[v] = 1;
    }
    for (int i = 1; i <= n; i++) {
        if (vis[i] == 0) {
            return 0;
        }
    }
    return 1;
}

int main()
{
    scanf("%d %d", &n, &m);
    for (int i = 0; i < m; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        graph[u][v] = 1, graph[v][u] = 1;
    }
    scanf("%d", &k);
    for (int i = 0 ; i < k; i++) {
        memset(seq, 0, sizeof(seq));
        scanf("%d", &d);
        for (int j = 0; j < d; j++) {
            scanf("%d", &seq[j]);
        }
        printf("%s\n", IsHam() == 1 ? "YES" : "NO");
    }
    return 0;
}