#include <bits/stdc++.h>

int main()
{
    printf("What is a computer?\n");
    return 0;
}