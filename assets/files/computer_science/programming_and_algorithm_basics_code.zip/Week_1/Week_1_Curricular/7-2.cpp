#include <bits/stdc++.h>

long long n;

int main()
{
    scanf("%lld", &n);
    printf("%lld\n", n*n*n);
    return 0;
}