#include <bits/stdc++.h>

int a,b;

int main()
{
    scanf("%d%d", &a, &b);
    printf("%d\n", a + b);
    return 0;
}