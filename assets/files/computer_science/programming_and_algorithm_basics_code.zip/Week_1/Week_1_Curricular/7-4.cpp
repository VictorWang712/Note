#include <bits/stdc++.h>

int h1, h2, m1, m2, d, h3, m3;
char s1[20], s2[20];

int main()
{
    scanf("%s%s", s1, s2);
    h1 = (s1[0] - '0') * 10 + (s1[1] - '0'), h2 = (s2[0] - '0') * 10 + (s2[1] - '0');
    m1 = (s1[3] - '0') * 10 + (s1[4] - '0'), m2 = (s2[3] - '0') * 10 + (s2[4] - '0');
    //printf("%d %d %d %d\n", h1, m1, h2, m2);
    d = (h2 * 60 + m2) - (h1 * 60 + m1);
    h3 = d/60, m3 = d%60;
    printf("%d %d\n", h3, m3);
    return 0;
}