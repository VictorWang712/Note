#include <bits/stdc++.h>

int n, sum;
double ans;

int main()
{
    while (true) {
        int x;
        scanf("%d", &x);
        if (x < 0) {
            ans = (double)sum / n;
            break;
        }
        else {
            sum += x, n++;
        }
    }
    if (n != 0) {
        printf("%.2lf\n", ans);
    }
    else {
        printf("None\n");
    }
    return 0;
}