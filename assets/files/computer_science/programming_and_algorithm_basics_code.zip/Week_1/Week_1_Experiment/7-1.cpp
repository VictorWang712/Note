#include <bits/stdc++.h>

int a;

int main()
{
    scanf("%d", &a);
    printf("%s\n", a % 2 == 0 ? "yes" : "no");
    return 0;
}