#include <bits/stdc++.h>

int n;

int main()
{
    scanf("%d", &n);
    printf("%s\n", ((n % 4 == 0) && (n % 100 != 0)) || (n % 400 == 0) ? "yes" : "no");
    return 0;
}