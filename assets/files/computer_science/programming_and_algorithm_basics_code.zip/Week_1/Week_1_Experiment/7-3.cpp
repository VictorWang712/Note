#include <bits/stdc++.h>

int cnt1, cnt2;

int main()
{
    while (true) {
        int x;
        scanf("%d", &x);
        if (x == 0) {
            break;
        }
        else if (x > 0) {
            cnt1++;
        }
        else if (x < 0) {
            cnt2++;
        }
    }
    printf("i=%d\nj=%d\n", cnt1, cnt2);
    return 0;
}