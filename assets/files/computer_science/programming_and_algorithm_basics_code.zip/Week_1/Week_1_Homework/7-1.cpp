#include <bits/stdc++.h>

int x, y;

int main()
{
    scanf("%d", &x);
    if (x % 2 == 0) {
        y = x * 2;
    }
    else if (x % 2 == 1) {
        y = x * 3;
    }
    printf("y=%d\n", y);
    return 0;
}