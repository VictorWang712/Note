#include <bits/stdc++.h>

int v;
std::string s;

int main()
{
    scanf("%d", &v);
    if (v > 60) {
        s = "Speeding";
    }
    else {
        s = "OK";
    }
    printf("Speed: %d - ", v), std::cout << s << std::endl;
    return 0;
}