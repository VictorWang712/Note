#include <bits/stdc++.h>

int a, b, h1, h2, h3, m1, m2, m3, d;

int main()
{
    scanf("%d%d", &a, &b);
    h1 = a / 100, h2 = b / 100, m1 = a % 100, m2 = b % 100;
    d =  (h2 * 60 + m2) - (h1 * 60 + m1);
    h3 = d / 60, m3 = d % 60;
    if (h3 < 10) {
        printf("0%d:", h3);
    }
    else {
        printf("%d:", h3);
    }
    if (m3 < 10) {
        printf("0%d\n", m3);
    }
    else {
        printf("%d\n", m3);
    }
    return 0;
}