#include <bits/stdc++.h>

int max;

int main()
{
    while (true) {
        int x;
        scanf("%d", &x);
        if (x < 0) {
            break;
        }
        else {
            max = std::max(x, max);
        }
    }
    printf("%d\n", max);
    return 0;
}