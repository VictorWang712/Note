#include <bits/stdc++.h>

int n, ans;

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < 32; i++) {
        if (n < std::pow(2, i)) {
            ans = 32 - i;
            break;
        }
    }
    if (n < 0) {
        ans = 0;
    }
    printf("%d\n", ans);
    return 0;
}