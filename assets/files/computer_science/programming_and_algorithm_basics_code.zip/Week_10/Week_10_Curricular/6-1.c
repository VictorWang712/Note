#include <string.h>

void delchar(char *str, char c) {
    int len = strlen(str);
    for (int i = 0; i < len; i++) {
        while (str[i] == c) {
            for (int j = i ; j <= len; j++) {
                str[j] = str[j + 1];
            }
        }
    }
    return;
}