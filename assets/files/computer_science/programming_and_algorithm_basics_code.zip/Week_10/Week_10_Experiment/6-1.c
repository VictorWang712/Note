void splitfloat(float x, int *intpart, float *fracpart) {
    for (int i = 0; i < 10000; i++) {
        if (x >= i && x < i + 1) {
            *intpart = i;
            break;
        }
    }
    *fracpart = x - *intpart;
    return;
}