void TimeInput(int *hour, int *minute, double *second) {
    int h = -1, m = -1;
    double s = -1;
    scanf(" %d : %d : %lf", &h, &m, &s);
    if (TimeIsValid(h, m, s) == 1) {
        *hour = h, *minute = m, *second = s;
    }
    return;
}