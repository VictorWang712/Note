void RealSwap(double *x, double *y) {
    double tmp;
    tmp = *x, *x = *y, *y = tmp;
    return;
}