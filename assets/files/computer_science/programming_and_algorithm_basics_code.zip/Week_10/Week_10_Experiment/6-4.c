int cnta = 0, cntb = 0;
pk = c;
while (cnta < anum && cntb < bnum) {
    if (a[cnta] <= b[cntb]) {
        *pk = a[cnta], cnta++, pk++;
    }
    else {
        *pk = b[cntb], cntb++, pk++;
    }
}
while (cnta < anum) {
    *pk = a[cnta], cnta++, pk++;
}
while (cntb < bnum) {
    *pk = b[cntb], cntb++, pk++;
}
for (int i = 0; i < anum + bnum; i++) {
    printf("%d", c[i]);
    if (i != anum + bnum - 1) {
        printf(" ");
    }
}