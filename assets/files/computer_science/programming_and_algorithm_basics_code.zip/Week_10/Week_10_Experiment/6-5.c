void moveleft(int *p, int n) {
    int b[6];
    for (int i = 0; i < 6; i++) {
        int j = (i - n) % 6;
        if (j < 0) {
            j += 6;
        }
        b[j] = p[i];
    }
    for (int i = 0; i < 6; i++) {
        p[i] = b[i];
    }
    return;
}