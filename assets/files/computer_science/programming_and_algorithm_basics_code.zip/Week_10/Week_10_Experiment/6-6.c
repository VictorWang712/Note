int hmean(const int x, const int y, float* r) {
    int ret = 1;
    if (x + y == 0) {
        ret = 0;
    }
    else {
        *r = (double)(x * y * 2.0) / (double)(x + y);
    }
    return ret;
}