int pstr_scan(char* str, int size) {
    int ret = 0;
    char c;
    while (c = getchar()) {
        if (c == ' ' || c == '\t' || c == '\n' || ret >= size) {
            break;
        }
        else {
            str[ret] = c;
            ret++;
        }
    }
    return ret;
}

void pstr_print(const char* str, int length) {
    for (int i = 0; i < length; i++) {
        printf("%c", str[i]);
    }
    printf("\n");
    return;
}