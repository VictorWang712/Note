int pstr_cmp(const char *s1, int len1, const char *s2, int len2) {
    int ret = 0, len = len1, flag = 0;
    if (len1 < len2) {
        len = len1, flag = 1;
    }
    else if (len1 > len2) {
        len = len2, flag = 2;
    }
    for (int i = 0; i < len; i++) {
        ret = s1[i] - s2[i];
        if (ret != 0) {
            break;
        }
    }
    if (ret == 0 && flag != 0) {
        if (flag == 1) {
            ret = -s2[len];
        }
        else if (flag == 2) {
            ret = s1[len];
        }
    }
    return ret;
}