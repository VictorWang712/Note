int pstr_cpy(char *s1, int len1, int size, const char *s2, int len2) {
    int ret = 0;
    while (ret < len2 && ret < size) {
        s1[ret] = s2[ret];
        ret++;
    }
    return ret;
}

int pstr_cat(char *s1, int len1, int size, const char *s2, int len2) {
    int ret = len1;
    while (ret < len1 + len2 && ret < size) {
        s1[ret] = s2[ret - len1];
        ret++;
    }
    return ret;
}