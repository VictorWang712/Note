int prt_esc_char(const char *s) {
    int ret = 0;
    for (int i = 0; s[i] != '\0'; i++) {
        if (s[i] == '\n' || s[i] == '\r' || s[i] == '\t' || s[i] == 'b') {
            switch(s[i]) {
                case '\n':
                    putchar('\\'), putchar('n');
                    ret += 2;
                    break;
                case '\r':
                    putchar('\\'), putchar('r');
                    ret += 2;
                    break;
                case '\t':
                    putchar('\\'), putchar('t');
                    ret += 2;
                    break;
                case '\b':
                    putchar('\\'), putchar('b');
                    ret += 2;
                    break;
                    
            }
        }
        else if (s[i] < 0x20) {
            putchar('\\'), putchar(s[i] / 16 + '0'), putchar(s[i] % 16 + '0');
            ret += 3;
        }
        else {
            putchar(s[i]);
            ret++;
        }
    }
    return ret;
}