void ArrayShift(int a[], int n, int m) {
    int b[100];
    for (int i = 0; i < n; i++) {
        int j = (i + m) % n;
        if (j < 0) {
            j += n;
        }
        b[j] = a[i];
    }
    for (int i = 0; i < n; i++) {
        a[i] = b[i];
    }
    return;
}