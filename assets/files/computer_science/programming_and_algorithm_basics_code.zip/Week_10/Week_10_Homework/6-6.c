void fun(int *a, int n, int *max, int *min) {
    *max = -0x3f3f3f3f, *min = 0x3f3f3f3f;
    for (int i = 0; i < n; i++) {
        if (a[i] > *max) {
            *max = a[i];
        }
        if (a[i] < *min) {
            *min = a[i];
        }
    }
    return;
}