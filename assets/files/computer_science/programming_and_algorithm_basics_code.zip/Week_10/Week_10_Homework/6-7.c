int cnt[100];

int fun( int a[], int n) {
    int ret = 0;
    for (int i = 0; i < n; i++) {
        cnt[a[i]]++;
    }
    for (int i = 0; i < 100; i++) {
        if (cnt[i] > cnt[ret]) {
            ret = i;
        }
    }
    return ret;
}