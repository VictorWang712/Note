int fun (int *D, int N) {
    int cnt = 0;
    for (int i = 0; i < N; i++) {
        if (D[i] > D[cnt]) {
            cnt++, D[cnt] = D[i];
        }
    }
    return cnt + 1;
}