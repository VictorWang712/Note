int hmean(const int x, const int y, float *r) {
    if (x + y == 0) {
        return 0;
    }
    else {
        *r = (double)(x * y * 2) / (x + y);
        return 1;
    }
}