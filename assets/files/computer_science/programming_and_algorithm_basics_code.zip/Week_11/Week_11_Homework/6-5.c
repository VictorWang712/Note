bool palindrome(char *s) {
    int len;
    bool ret = true;
    while (s[len] != '\0') {
        len++;
    }
    for (int i = 0; i < len; i++) {
        if (s[i] != s[len - i - 1]) {
            ret = false;
            break;
        }
    }
    return ret;
}