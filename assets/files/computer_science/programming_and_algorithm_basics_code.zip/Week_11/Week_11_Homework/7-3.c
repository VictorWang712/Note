#include <stdio.h>

int n, len;
char s[100];

int main()
{
    while (s[len] = getchar()) {
        if (s[len] == '\n') {
            s[len] = '\0';
            break;
        }
        len++;
    }
    scanf("%d", &n);
    for (int i = 0; i < len; i++) {
        if (s[i] >= 'a' && s[i] <= 'z') {
            int x = s[i] - 'a';
            x = (x + n) % 26;
            if (x < 0) {
                x += 26;
            }
            s[i] = x + 'a';
        }
        else if (s[i] >= 'A' && s[i] <= 'Z') {
            int x = s[i] - 'A';
            x = (x + n) % 26;
            if (x < 0) {
                x += 26;
            }
            s[i] = x + 'A';
        }
    }
    printf("%s\n", s);
    return 0;
}