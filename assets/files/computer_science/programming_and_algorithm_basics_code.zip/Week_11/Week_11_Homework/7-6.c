#include <stdio.h>
#include <string.h>

int len, ans, minus;
char s[110];

int main()
{
    scanf("%s", s);
    len = strlen(s);
    for (int i = 0; i < len; i++) {
        if (s[i] == '-' && minus == 0) {
            minus = 1;
        }
        else if (s[i] >= '0' && s[i] <= '9') {
            ans *= 16, ans += s[i] - '0';
            if (minus == 0) {
                minus = -1;
            }
        }
        else if (s[i] >= 'a' && s[i] <= 'f') {
            ans *= 16, ans += s[i] - 'a' + 10;
            if (minus == 0) {
                minus = -1;
            }
        }
        else if (s[i] >= 'A' && s[i] <= 'F') {
            ans *= 16, ans += s[i] - 'A' + 10;
            if (minus == 0) {
                minus = -1;
            }
        }
    }
    if (minus == 1) {
        ans = -ans;
    }
    printf("%d\n", ans);
    return 0;
}