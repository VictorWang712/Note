#include <stdio.h>
#include <string.h>

int len;
int vis[310];
char c;

int main() {
    while (c = getchar()) {
        if (c == '\n') {
            break;
        }
        vis[c] = 1;
    }
    for (int i = 0; i < 128; i++) {
        if (vis[i] == 1) {
            printf("%c", i);
        }
    }
    printf("\n");
    return 0;
}