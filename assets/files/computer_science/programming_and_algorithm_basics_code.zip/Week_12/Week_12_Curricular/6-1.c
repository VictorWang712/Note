struct complex add(struct complex n1, struct complex n2) {
    struct complex ret = (struct complex){0, 0};
    ret.real = n1.real + n2.real;
    ret.imag = n1.imag + n2.imag;
    return ret;
}