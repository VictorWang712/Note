char *dstr_create(const char *s) {
    char *ret = (char*)malloc(sizeof(char));
    for (int i = 0; s[i] != '\0'; i++) {
        ret[i] = s[i];
        ret = (char*)realloc(ret, (i + 2) * sizeof(char));
    }
    return ret;
}