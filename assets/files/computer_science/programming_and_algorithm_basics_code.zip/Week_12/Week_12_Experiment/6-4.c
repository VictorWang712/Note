char *dstr_add(char *s, char c) {
    int len = strlen(s);
    char *ret = (char*)malloc((len + 1) * sizeof(char));
    for (int i = 0; i < len; i++) {
        ret[i] = s[i];
    }
    ret[len] = c, ret[len + 1] = '\0';
    return ret;
}

char *dstr_concat(char *this, const char *that) {
    int len1 = strlen(this), len2 = strlen(that);
    char *ret = (char*)malloc((len1 + len2 + 1) * sizeof(char));
    for (int i = 0; i < len1; i++) {
        ret[i] = this[i];
    }
    for (int i = 0; i < len2; i++) {
        ret[len1 + i] = that[i];
    }
    ret[len1 + len2] = '\0';
    return ret;
}