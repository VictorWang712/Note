void pur_LinkList(LinkList L) {
    LNode *crt = L->next;
    while (crt != NULL) {
        LNode *prv = crt, *tmp = crt->next;
        while (tmp != NULL) {
            if (tmp->data == crt->data) {
                prv->next = tmp->next;
            }
            else {
                prv = tmp;
            }
            tmp = tmp->next;
        }
        crt = crt->next;
    }
    return;
}