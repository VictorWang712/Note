Polynomial Add(Polynomial a, Polynomial b) {
    Polynomial ret;
    struct Node *crta = a->Next, *crtb = b->Next, *crt = (struct Node*)malloc(sizeof(struct Node));
    crt->Coefficient = 0, crt->Exponent = 0, crt->Next = NULL;
    ret = crt;
    while (crta != NULL && crtb != NULL) {
        struct Node *tmp = (struct Node*)malloc(sizeof(struct Node));
        if (crta->Exponent > crtb->Exponent) {
            tmp->Coefficient = crta->Coefficient;
            tmp->Exponent = crta->Exponent;
            tmp->Next = NULL;
            crt->Next = tmp, crt = crt->Next;
            crta = crta->Next;
        }
        else if (crta->Exponent < crtb->Exponent) {
            tmp->Coefficient = crtb->Coefficient;
            tmp->Exponent = crtb->Exponent;
            tmp->Next = NULL;
            crt->Next = tmp, crt = crt->Next;
            crtb = crtb->Next;
        }
        else {
            tmp->Coefficient = crta->Coefficient + crtb->Coefficient;
            tmp->Exponent = crta->Exponent;
            if (tmp->Coefficient != 0) {
                tmp->Next = NULL;
                crt->Next = tmp, crt = crt->Next;
            }
            else {
                free(tmp);
            }
            crta = crta->Next, crtb = crtb->Next;
        }
    }
    while (crta != NULL) {
        struct Node *tmp = (struct Node*)malloc(sizeof(struct Node));
        tmp->Coefficient = crta->Coefficient;
        tmp->Exponent = crta->Exponent;
        tmp->Next = NULL;
        crt->Next = tmp, crt = crt->Next;
        crta = crta->Next;
    }
    while (crtb != NULL) {
        struct Node *tmp = (struct Node*)malloc(sizeof(struct Node));
        tmp->Coefficient = crtb->Coefficient;
        tmp->Exponent = crtb->Exponent;
        tmp->Next = NULL;
        crt->Next = tmp, crt = crt->Next;
        crtb = crtb->Next;
    }
    return ret;
}