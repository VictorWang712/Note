PtrToNode Suffix(List L1, List L2) {
    int len1 = 0, len2 = 0;
    struct Node *crt1 = L1->Next, *crt2 = L2->Next;
    while (crt1 != NULL) {
        len1++;
        crt1 = crt1->Next;
    }
    while (crt2 != NULL) {
        len2++;
        crt2 = crt2->Next;
    }
    crt1 = L1->Next, crt2 = L2->Next;
    while (len1 > len2) {
        crt1 = crt1->Next;
        len1--;
    }
    while (len1 < len2) {
        crt2 = crt2->Next;
        len2--;
    }
    while (crt1 != NULL) {
        if (crt1 == crt2) {
            return crt1;
        }
        crt1 = crt1->Next, crt2 = crt2->Next;
    }
    return NULL;
}