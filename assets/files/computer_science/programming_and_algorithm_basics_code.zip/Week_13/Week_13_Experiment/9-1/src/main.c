#include <stdio.h>

int a, b;

int main() {
    if(freopen("in.txt", "r", stdin) == NULL) {
        return -1;
    }
    freopen("out.txt", "w", stdout);
    scanf("%d%d", &a, &b);
    printf("%d\n", a + b);
    return 0;
}