List Merge(List L1, List L2) {
    List head = (List)malloc(sizeof(struct Node)), ind = head, tmp1 = L1->Next, tmp2 = L2->Next;
    L1->Next = NULL, L2->Next = NULL;
    while (tmp1 != NULL && tmp2 != NULL) {
        if (tmp1->Data <= tmp2->Data) {
            ind->Next = tmp1, tmp1 = tmp1->Next;
        }
        else {
            ind->Next = tmp2, tmp2 = tmp2->Next;
        }
        ind = ind->Next;
    }
    if (tmp1 != NULL) {
        ind->Next = tmp1;
    }
    else if (tmp2 != NULL) {
        ind->Next = tmp2;
    }
    return head;
}