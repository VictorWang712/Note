void list_append(List *list, int value) {
    Node *new = (Node*)malloc(sizeof(Node));
    new->value = value, new->next = NULL;
    if (list->head == NULL) {
        new->prev = NULL;
        list->head = new, list->tail = new;
    }
    else {
        list->tail->next = new;
        new->prev = list->tail;
        list->tail = new;
    }
    return;
}

void list_remove(List *list, int value) {
    Node *crt = list->head;
    while (crt != NULL) {
        if (crt->value == value) {
            Node *tmp = crt;
            if (crt->prev != NULL) {
                crt->prev->next = crt->next;
            }
            else {
                list->head = crt->next;
            }
            if (crt->next != NULL) {
                crt->next->prev = crt->prev;
            }
            else {
                list->tail = crt->prev;
            }
            crt = crt->next;
            free(tmp);
        }
        else {
            crt = crt->next;
        }
    }
    return;
}