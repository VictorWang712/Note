int myCreate(struct stu *head, int m) {
    if (m < 1 || m > 100) {
        return 0;
    }
    struct stu *crt = head;
    for (int i = 0; i < m; i++) {
        struct stu *new = (struct stu*)malloc(sizeof(struct stu));
        if (new == NULL) {
            return 0;
        }
        if (scanf("%s %d", new->name, &new->no) != 2) {
            free(new);
            return 0;
        }
        new->next = NULL;
        crt->next = new, crt = crt->next;
    }
    return 1;
}

void show(struct stu *head) {
    struct stu *crt = head->next;
    while (crt != NULL) {
        printf("%s %d\n", crt->name, crt->no);
        crt = crt->next;
    }
    return;
}

struct stu *myIndex(struct stu *head, char *s) {
    struct stu *crt = head->next;
    while (crt != NULL) {
        if (strcmp(crt->name, s) == 0) {
            return crt;
        }
        crt = crt->next;
    }
    return NULL;
}

int myDel(struct stu *head, char *s) {
    struct stu *crt = head;
    while (crt->next != NULL) {
        if (strcmp(crt->next->name, s) == 0) {
            struct stu *tmp = crt->next;
            crt->next = tmp->next;
            free(tmp);
            return 1;
        }
        crt = crt->next;
    }
    return 0;
}