void show(struct Node *r) {
    if (r == NULL) {
        printf("[]\n");
    }
    else {
        struct Node *crt = r->next;
        printf("[");
        do {
            printf("%d", crt->data);
            if (crt != r) {
                printf(",");
            }
            crt = crt->next;
        } while (crt != r->next);
        printf("]\n");
    }
    return;
}