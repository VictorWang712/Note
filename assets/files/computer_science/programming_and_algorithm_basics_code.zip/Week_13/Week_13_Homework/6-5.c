Position Find(List L, ElementType X) {
    Position crt = L;
    while (crt != NULL) {
        if (crt->Data == X) {
            return crt;
        }
        crt = crt->Next;
    }
    return ERROR;
}

List Insert(List L, ElementType X, Position P) {
    if (L == NULL) {
        Position new = (Position)malloc(sizeof(Position));
        new->Data = X, new->Next = NULL;
        L = new;
        return L;
    }
    Position crt = L;
    if (crt == P) {
        Position new = (Position)malloc(sizeof(Position));
        new->Data = X, new->Next = P;
        return new;
    }
    while (crt != NULL) {
        if (crt->Next == P) {
            Position new = (Position)malloc(sizeof(Position));
            crt->Next = new;
            new->Data = X, new->Next = P;
            return L;
        }
        crt = crt->Next;
    }
    printf("Wrong Position for Insertion\n");
    return ERROR;
}

List Delete(List L, Position P) {
    Position crt = L;
    if (crt == P) {
        return L->Next;
    }
    while (crt != NULL) {
        if (crt->Next == P) {
            crt->Next = P->Next;
            return L;
        }
        crt = crt->Next;
    }
    printf("Wrong Position for Deletion\n");
    return ERROR;
}