List MakeEmpty() {
    List new = (List)malloc(sizeof(List));
    new->Data = 0, new->Next = NULL;
    return new;
}

Position Find(List L, ElementType X) {
    Position crt = L;
    while (crt != NULL) {
        if (crt->Data == X) {
            return crt;
        }
        crt = crt->Next;
    }
    return ERROR;
}

bool Insert(List L, ElementType X, Position P) {
    if (L == NULL) {
        Position new = (Position)malloc(sizeof(Position));
        new->Data = X, new->Next = NULL;
        L = new;
        return true;
    }
    Position crt = L;
    if (crt == P) {
        Position new = (Position)malloc(sizeof(Position));
        new->Data = X, new->Next = P;
        L = new;
        return true;
    }
    while (crt != NULL) {
        if (crt->Next == P) {
            Position new = (Position)malloc(sizeof(Position));
            crt->Next = new;
            new->Data = X, new->Next = P;
            return true;
        }
        crt = crt->Next;
    }
    printf("Wrong Position for Insertion\n");
    return false;
}

bool Delete(List L, Position P) {
    Position crt = L;
    if (crt == P) {
        L = crt->Next;
        return true;
    }
    while (crt != NULL) {
        if (crt->Next == P) {
            crt->Next = P->Next;
            return true;
        }
        crt = crt->Next;
    }
    printf("Wrong Position for Deletion\n");
    return false;
}