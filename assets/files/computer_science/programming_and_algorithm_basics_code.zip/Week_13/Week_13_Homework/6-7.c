void K_Reverse(List L, int K) {
    if (L == NULL || K <= 1) {
        return;
    }
    struct Node *lst = L, *head = lst->Next, *tail;
    while (head != NULL) {
        //divide segment
        tail = head;
        for (int i = 0; i < K - 1; i++) {
            tail = tail->Next;
            if (tail == NULL) {
                return;
            }
        }

        //reverse segment
        struct Node *crt = head, *nxthead = tail->Next, *prv = nxthead;
        while (crt != nxthead) {
            struct Node *tmp = crt;
            crt = crt->Next;
            tmp->Next = prv;
            prv = tmp;

        }

        //switch to next segment
        lst->Next = tail, lst = head, head = lst->Next;
    }
    return;
}