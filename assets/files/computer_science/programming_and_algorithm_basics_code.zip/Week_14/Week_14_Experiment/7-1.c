#include <stdio.h>

int a, b, flag;

int Judge(int x) {
    long long sum = 0;
    for (int i = 1; i * 2 <= x; i++) {
        if (x % i == 0) {
            sum += i;
        }
    }
    if (sum == x) {
        return 1;
    }
    else {
        return 0;
    }
}

int main()
{
    scanf("%d %d", &a, &b);
    for (int i = a; i <= b; i++) {
        if (Judge(i) == 1) {
            printf("%d\n", i);
            flag = 1;
        }
    }
    if (flag == 0) {
        printf("None\n");
    }
    return 0;
}