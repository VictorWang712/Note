#include <stdio.h>

int n, x;
long long ans, base;

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        ans = 0, base = 5;
        scanf("%d", &x);
        while (base <= x) {
            ans += x / base;
            base *= 5;
        }
        printf("%lld\n", ans);
    }
    return 0;
}