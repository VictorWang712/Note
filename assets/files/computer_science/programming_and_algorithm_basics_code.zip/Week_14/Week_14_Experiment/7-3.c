#include <stdio.h>
#include <string.h>
#define N 110

int len, lena, lenb;
int a[N], b[N], ans[N];
char s[N];

int main()
{
    scanf("%s", s);
    lena = strlen(s);
    if (lena > len) {
        len = lena;
    }
    for (int i = 0; i < lena; i++) {
        a[lena - i - 1] = s[i] - '0';
    }
    /*
    for (int i = 0; i < lena; i++) {
        printf("%d", a[lena - i - 1]);
    }
    printf("\n");
    */
    scanf("%s", s);
    lenb = strlen(s);
    lena = strlen(s);
    if (lenb > len) {
        len = lenb;
    }
    for (int i = 0; i < lenb; i++) {
        b[lenb - i - 1] = s[i] - '0';
    }
    /*
    for (int i = 0; i < lenb; i++) {
        printf("%d", b[lenb - i - 1]);
    }
    printf("\n");
    */
    if (a[len - 1] + b[len - 1] >= 10) {
        len++;
    }
    for (int i = 0; i < len; i++) {
        ans[i] += (a[i] + b[i]) % 10;
        ans[i + 1] += (a[i] + b[i]) / 10;
    }
    for (int i = 0; i < len; i++) {
        printf("%d", ans[len - i - 1]);
    }
    printf("\n");
    return 0;
}