#!/bin/bash
make clean
make
./test $1