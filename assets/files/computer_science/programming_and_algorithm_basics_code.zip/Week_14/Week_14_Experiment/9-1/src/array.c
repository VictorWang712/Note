#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "array.h"

Array array_create() {
    Array new;
    new.content = (int*)malloc(BLOCK_SIZE * sizeof(int)), new.size = BLOCK_SIZE;
    memset(new.content, 0, new.size * sizeof(int));
    return new;
}

void array_free(Array* array) {
    if (array->content != NULL) {
        free(array->content);
        array->content = NULL;
    }
    array->size = 0;
    return;
}

int array_size(const Array *array) {
    return array->size;
}

void array_inflate(Array *array) {
    int new_size = array->size + BLOCK_SIZE;
    int *new_content = (int*)realloc(array->content, new_size * sizeof(int));
    memset(new_content + array->size, 0, BLOCK_SIZE * sizeof(int));
    array->content = new_content, array->size = new_size;
    return;
}

int array_get(const Array *array, int index) {
    return array->content[index];
}

void array_set(Array *array, int index, int value) {
    array->content[index] = value;
    return;
}

Array array_clone(const Array *array) {
    Array new;
    new.size = array->size;
    new.content = (int*)malloc(new.size * sizeof(int));
    memcpy(new.content, array->content, new.size * sizeof(int));
    return new;
}