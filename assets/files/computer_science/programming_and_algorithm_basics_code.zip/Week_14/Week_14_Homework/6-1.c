int Power(int N, int k) {
    long long ret = 1, tmp = N;
    while (k != 0) {
        if (k % 2 == 1) {
            ret *= tmp, ret %= MOD;
        }
        tmp *= tmp, tmp %= MOD;
        k /= 2;
    }
    return (int)ret;
}