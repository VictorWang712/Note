#include <stdio.h>
#define N 10

int n, cnt, ans, base = 1;
int dgt[N];

int main()
{
    scanf("%d", &n);
    while (n != 0) {
        dgt[cnt] = n % 16;
        n/=16;
        cnt++;
    }
    for (int i = 0; i * 2 <= cnt; i++) {
        ans += (dgt[i * 2] + dgt[i * 2 + 1] * 10) * base;
        base *= 10;
    }
    printf("%d\n", ans);
    return 0;
}