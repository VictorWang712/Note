#include <stdio.h>
#include <stdint.h>

union Data {
    double x;
    uint64_t code;
};


int main()
{
    union Data u;
    scanf("%lf", &u.x);
    printf("%016llX\n", u.code);
    return 0;
}