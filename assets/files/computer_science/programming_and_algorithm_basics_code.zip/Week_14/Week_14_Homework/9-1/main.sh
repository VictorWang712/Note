#!/bin/bash
#make clean
make -B
./test $1