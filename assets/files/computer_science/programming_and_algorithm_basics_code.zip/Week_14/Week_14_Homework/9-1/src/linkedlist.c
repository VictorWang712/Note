#include "linkedlist.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct _node {
    int value;
    struct _node *next;
} Node;

List list_create() {
    List *new = (List*)malloc(sizeof(List));
    new->head = NULL, new->tail = NULL;
    return *new;
}

void list_free(List *list) {
    Node *crt = list->head;
    while (crt != NULL) {
        Node *tmp = crt;
        crt = crt->next;
        free(tmp);
    }
    list->head = NULL, list->tail = NULL;
    return;
}

void list_append(List *list, int v) {
    Node *new = (Node*)malloc(sizeof(Node));
    new->value = v, new->next = NULL;
    if (list->tail != NULL) {
        list->tail->next = new, list->tail = new;
    }
    else {
        list->head = new, list->tail = new;
    }
    return;
}

void list_insert(List *list, int v) {
    Node *new = (Node*)malloc(sizeof(Node));
    new->value = v, new->next = NULL;
    if (list->head != NULL) {
        new->next = list->head, list->head = new;
    }
    else {
        list->head = new, list->tail = new;
    }
    return;
}

void list_set(List *list, int index, int v) {
    Node *crt = list->head;
    for (int i = 0; i < index; i++) {
        crt = crt->next;
    }
    crt->value = v;
    return;
}

int list_get(List *list, int index) {
    Node *crt = list->head;
    for (int i = 0; i < index; i++) {
        crt = crt->next;
    }
    return crt->value;
}

int list_size(List *list) {
    int ret = 0;
    Node *crt = list->head;
    while (crt != NULL) {
        ret++, crt = crt->next;
    }
    return ret;
}

int list_find(List *list, int v) {
    int ind = 0;
    Node *crt = list->head;
    while (crt != NULL) {
        if (crt->value == v) {
            return ind;
        }
        crt = crt->next, ind++;
    }
    return -1;
}

void list_remove(List *list, int v) {
    Node *crt = list->head, *prv = NULL;
    while (crt != NULL) {
        if (crt->value == v) {
            if (crt == list->head) {
                list->head = crt->next;
            }
            if (crt == list->tail) {
                list->tail = prv;
            }
            if (prv != NULL) {
                prv->next = crt->next;
            }
            Node *tmp = crt;
            crt = crt->next;
            free(tmp);
        }
        else {
            prv = crt, crt = crt->next;
        }
    }
    return;
}

void list_iterate(List *list, void (*func)(int v)) {
    Node *crt = list->head;
    while (crt != NULL) {
        func(crt->value);
        crt = crt->next;
    }
    return;
}