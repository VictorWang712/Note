#include <bits/stdc++.h>

int cnt1, cnt2, sum1, sum2;
double av1, av2;

int main()
{
    while (true) {
        int x;
        scanf("%d", &x);
        if (x == 0) {
            break;
        }
        else if (x % 2 == 0) {
            cnt1++, sum1 += x;
        }
        else if (x % 2 == 1) {
            cnt2++, sum2 += x;
        }
    }
    if (cnt1 != 0) {
        av1 = (double)sum1 / cnt1;
    }
    if (cnt2 != 0) {
        av2 = (double)sum2 / cnt2;
    }
    printf("av1=%.2lf,av2=%.2lf", av1, av2);
    return 0;
}