#include <bits/stdc++.h>
#define N 40

int n, x, max, min, k;

int FindMax(int x) {
    int ret = 0, cnt = 0;
    int a[N];
    while (x != 0) {
        a[cnt++] = x % 10, x /= 10;
    }
    std::sort(a, a + cnt);
    for (int i = cnt - 1; i >= 0; i--) {
        ret += a[i];
        if(i != 0) {
            ret *= 10;
        }
    }
    return ret;
}

int FindMin(int x) {
    int ret = 0, cnt = 0;
    int a[N];
    while (x != 0) {
        a[cnt++] = x % 10, x /= 10;
    }
    std::sort(a, a + cnt);
    for (int i = 0; i < cnt; i++) {
        ret += a[i];
        if(i != cnt - 1) {
            ret *= 10;
        }
    }
    return ret;
}

int main()
{
    scanf("%d", &n);
    x = n;
    while (true) {
        k++, max = FindMax(x), min = FindMin(x), x = max - min;
        printf("%d: %d - %d = %d\n", k, max, min, x);
        if (x == 495) {
            break;
        }
    }
    return 0;
}