#include <bits/stdc++.h>

int n, sum, cnt;
int a[1010];
double avr;

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < n; i++) {
        sum += a[i];
        if (a[i] >= 60) {
            cnt++;
        }
    }
    avr = (double)sum / n;
    if (n == 0) {
        avr = 0;
    }
    printf("average = %.1lf\ncount = %d\n", avr, cnt);
    return 0;
}