#include <bits/stdc++.h>

int n, cnt;

int main()
{
    scanf("%d", &n);
    while (true) {
        if (n == 1) {
            break;
        }
        if (n % 2 == 1) {
            n = n * 3 + 1;
        }
        else if (n % 2 == 0) {
            n /= 2;
        }
        cnt++;
    }
    printf("%d\n", cnt);
    return 0;
}