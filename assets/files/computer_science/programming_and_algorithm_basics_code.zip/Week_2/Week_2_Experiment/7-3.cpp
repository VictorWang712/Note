#include <bits/stdc++.h>

int n;
long long ans;

int main()
{
    scanf("%d", &n);
    ans = 1;
    while (n != 0) {
        int x = n % 10;
        ans *= x, n /= 10;
    }
    printf("%lld\n", ans);
    return 0;
}