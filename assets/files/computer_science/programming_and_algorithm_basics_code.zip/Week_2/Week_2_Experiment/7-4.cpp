#include <bits/stdc++.h>

int n, cnt;
int dig[20];
bool minus, fir;

int main()
{
    scanf("%d", &n);
    if (n < 0) {
        minus = true;
    }
    n = std::abs(n);
    while (n != 0) {
        dig[cnt++] = n % 10;
        n /= 10;
    }
    if (minus == true) {
        printf("-");
    }
    for (int i = 0; i < cnt; i++) {
        if (dig[i] == 0 && fir == false) {
            continue;
        }
        if (dig[i] != 0 && fir == false) {
            fir = true;
        }
        printf("%d", dig[i]);
    }
    if (fir == false) {
        printf("0");
    }
    printf("\n");
    return 0;
}