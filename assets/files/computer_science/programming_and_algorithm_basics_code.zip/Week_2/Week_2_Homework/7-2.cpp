#include <bits/stdc++.h>

int a, b;

int Reverse(int x) {
    int ret = 0, cnt = 0;
    int a[40];
    while (x != 0) {
        a[cnt++] = x % 10, x /= 10;
    }
    for (int i = 0; i < cnt; i++) {
        //printf("a[%d] = %d\n", i, a[i]);
        ret += a[i];
        if(i != cnt - 1) {
            ret *= 10;
        }
    }
    return ret;
}

int main()
{
    scanf("%d %d", &a, &b);
    printf("%d\n", Reverse(a*b));
    return 0;
}