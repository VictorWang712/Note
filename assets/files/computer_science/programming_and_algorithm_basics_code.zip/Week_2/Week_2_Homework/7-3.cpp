#include <bits/stdc++.h>
#define N 30010

int n, k;
int x[N];

int FindMax(int x) {
    int ret = 0, cnt = 0;
    int a[N];
    while (x != 0) {
        a[cnt++] = x % 10, x /= 10;
    }
    std::sort(a, a + cnt);
    for (int i = cnt - 1; i >= 0; i--) {
        ret += a[i];
        if(i != 0) {
            ret *= 10;
        }
    }
    return ret;
}

int Transform(int x) {
    int ret = 0;
    while (x != 0) {
        ret += x % 10, x /= 10;
    }
    ret = (ret * 3) + 1;
    return ret;
}

int main()
{
    scanf("%d", &n);
    x[0] = n;
    while (true) {
        k++, x[k] = Transform(x[k - 1]);
        printf("%d:%d\n", k, x[k]);
        if (x[k] == x[k - 1]) {
            break;
        }
    }
    return 0;
}