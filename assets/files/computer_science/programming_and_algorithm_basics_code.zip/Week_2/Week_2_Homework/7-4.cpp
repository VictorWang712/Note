#include <bits/stdc++.h>

int n, s, cnt;

int main()
{
    scanf("%d", &n);
    while (s < n) {
        s = s * 10 + 1;
        cnt++;
    }
    while (true) {
        printf("%d", s / n);
        if(s % n == 0) {
            break;
        }
        s = (s % n) * 10 + 1;
        cnt++;
    }
    printf(" %d\n", cnt);
    return 0;
}