#include <bits/stdc++.h>

int x;

bool IsPrime(int x) {
    bool ret = true;
    for (int i = 2; i * i <= x; i++) {
        if (x % i == 0) {
            ret = false;
            break;
        }
    }
    if (x == 1) {
        ret = false;
    }
    return ret;
}

int main()
{
    scanf("%d", &x);
    if (IsPrime(x) == true) {
        printf("%d is a prime number.\n", x);
    }
    else {
        printf("%d is not a prime number.\n", x);
    }
    return 0;
}