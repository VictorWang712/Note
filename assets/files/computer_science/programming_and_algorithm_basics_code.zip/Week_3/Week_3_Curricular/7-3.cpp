#include <bits/stdc++.h>

int n, cnt, ans;

bool IsPrime(int x) {
    bool ret = true;
    for (int i = 2; i * i <= x; i++) {
        if (x % i == 0) {
            ret = false;
            break;
        }
    }
    if (x == 1) {
        ret = false;
    }
    return ret;
}

int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= 10000; i++) {
        if(IsPrime(i) == true) {
            ans += i, cnt++;
            if(cnt == n) {
                break;
            }
        }
    }
    printf("%d\n", ans);
    return 0;
}