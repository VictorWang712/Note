#include <bits/stdc++.h>

int n;
int a[1010];
long long sum;

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        sum += a[i];
    }
    printf("%lld\n", sum);
    return 0;
}