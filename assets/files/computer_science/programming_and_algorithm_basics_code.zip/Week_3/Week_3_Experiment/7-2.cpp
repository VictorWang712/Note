#include <bits/stdc++.h>

int n;
long long k, sum;

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        k *= 10, k += 6;
        sum += k;
    }
    printf("%lld\n", sum);
    return 0;
}