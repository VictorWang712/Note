#include <bits/stdc++.h>

int x, y, z;
bool flag;

bool Check(int a, int b, int c) {
    bool ret;
    int tmp[10];
    memset(tmp, 0, sizeof(tmp));
    for (int i = 0; i < 10; i++) {
        if (i == a % 10) {
            tmp[i]++;
        }
        if (i == b % 10) {
            tmp[i]++;
        }
        if (i == c % 10) {
            tmp[i]++;
        }
    }
    if (tmp[3] == 1 && tmp[6] == 1 && tmp[9] == 1) {
        ret = true;
    }
    else {
        ret = false;
    }
    return ret;
}

int main()
{
    scanf("%d%d%d", &x, &y, &z);
    for (int i = 1; i <= 100; i++) {
        x++, y++, z++;
        if (Check(x, y, z) == true) {
            flag = true;
            printf("%d\n", i);
            break;
        }
    }
    if (flag == false) {
        printf("so sad!\n");
    }
    return 0;
}