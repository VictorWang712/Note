#include <bits/stdc++.h>

int n, k;

int main()
{
    scanf("%d", &n);
    k = 1;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n - i + 1; j++) {
            printf("%4d", k);
            k++;
        }
        printf("\n");
    }
    return 0;
}