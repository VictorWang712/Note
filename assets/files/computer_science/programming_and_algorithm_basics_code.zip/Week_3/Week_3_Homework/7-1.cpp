#include <bits/stdc++.h>

int n, l, d;
char c;

namespace WalkerV {
    void Read() {
        scanf("%d", &n);
        getchar();
        scanf("%c", &c);
        return;
    }

    void Solve() {
        if (n < 7) {
            l = 1, d = n - 1;
        }
        else {
            int tmp = 1;
            for (int i = 2; i <= 1000; i++) {
                tmp += i * 4 - 2; 
                if (tmp > n) {
                    l = i - 1;
                    break;
                }
                d = n - tmp;
            }
        }
        return;
    }

    void Print() {
        for (int i = 1; i <= l; i++) {
            for (int j = 1; j <= i - 1; j++) {
                printf(" ");
            }
            for (int j = 1; j <= (l - i + 1) * 2 - 1; j++) {
                printf("%c", c);
            }
            printf("\n");
        }
        for (int i = 2; i <= l; i++) {
            for (int j = 1; j <= (l - i); j++) {
                printf(" ");
            }
            for (int j = 1; j <= i * 2 - 1; j++) {
                printf("%c", c);
            }
            printf("\n");
        }
        printf("%d\n", d);
        return;
    }
}

int main()
{
    WalkerV::Read();
    WalkerV::Solve();
    WalkerV::Print();
    return 0;
}