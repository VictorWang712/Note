#include <bits/stdc++.h>

int a, b;

int main()
{
    for (int i = 1000; i <= 9999; i++) {
        a = i / 100, b = i % 100;
        if (i == (a + b) * (a + b)) {
            printf("%5d", i);
        }
    }
    printf("\n");
    return 0;
}