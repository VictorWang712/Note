#include <bits/stdc++.h>

int x, ans;

bool IsPrime(int x) {
    bool ret = true;
    for (int i = 2; i * i <= x; i++) {
        if (x % i == 0) {
            ret = false;
            break;
        }
    }
    if (x == 1) {
        ret = false;
    }
    return ret;
}

int main()
{
    scanf("%d", &x);
    int tmp = x + 1;
    while (true) {
        if (IsPrime(tmp) == true) {
            ans = tmp;
            break;
        }
        tmp++;
    }
    printf("%d\n", ans);
    return 0;
}