#include <bits/stdc++.h>
#define N 1010

int n, ans;
int a[N];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < n; i++) {
        ans = std::max(ans, a[i]);
    }
    printf("%d\n", ans);
    return 0;
}