#include <bits/stdc++.h>

int n;
bool flag;

int main()
{
    scanf("%d", &n);
    for (int i = 0; i <= n/3; i++) {
        for (int j = 0; j <= n/2; j++) {
            for (int k = 0; k <= n*2; k++) {
                if (i * 3 + j * 2 + k * 0.5 == n && i + j + k == n) {
                    printf("men = %d, women = %d, child = %d\n", i, j, k);
                    flag = true;
                }
            }
        }
    }
    if (flag == false) {
        printf("None\n");
    }
    return 0;
}