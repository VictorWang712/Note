#include <bits/stdc++.h>

int n;
double ans;

double Calc(int x) {
    double ret;
    ret = (double)x / (x * 2 - 1);
    if (x % 2 == 0) {
        ret = -ret;
    }
    return ret;
}

int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        ans += Calc(i);
    }
    printf("%.3lf\n", ans);
    return 0;
}