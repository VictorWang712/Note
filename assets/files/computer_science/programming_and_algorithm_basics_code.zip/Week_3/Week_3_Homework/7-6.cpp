#include <bits/stdc++.h>

int m, n;
int frac[10010];
bool flag;

void Calc(int x) {
    int tmp = 0, cnt = 0;
    memset(frac, 0, sizeof(frac));
    for (int i = 1; i * 2 <= x; i++) {
        if (x % i == 0) {
            frac[cnt] = i, cnt++;
            tmp += i;
        }
    }
    //printf("x = %d tmp = %d\n", x, tmp);
    if (x == tmp) {
        flag = true;
        printf("%d = ", x);
        for (int i = 0; i < cnt; i++) {
            printf("%d", frac[i]);
            if (i != cnt - 1) {
                printf(" + ");
            }
            else {
                printf("\n");
            }
        }
    }
    return;
}

int main()
{
    scanf("%d%d", &m, &n);
    for (int i = m; i <= n; i++) {
        Calc(i);
    }
    if (flag == false) {
        printf("None\n");
    }
    return 0;
}