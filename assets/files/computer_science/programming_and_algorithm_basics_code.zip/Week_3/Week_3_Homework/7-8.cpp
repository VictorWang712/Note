#include <bits/stdc++.h>

int n;

bool IsPrime(int x) {
    bool ret = true;
    for (int i = 2; i * i <= x; i++) {
        if (x % i == 0) {
            ret = false;
            break;
        }
    }
    if (x == 1) {
        ret = false;
    }
    return ret;
}

int main()
{
    scanf("%d", &n);
    int on = n;
    printf("%d=", n);
    if (IsPrime(n) == true) {
        printf("%d\n", n);
    }
    else {
        for (int i = 2; i * 2 <= on; i++) {
            if (IsPrime(i) == true) {
                while (n % i == 0) {
                    printf("%d", i);
                    n /= i;
                    if (n != 1) {
                        printf("*");
                    }
                }
            }
        }
    }
    return 0;
}