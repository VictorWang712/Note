#include <bits/stdc++.h>

int n;
long long ans;

int main()
{
    scanf("%d", &n);
    long long tmp = 1;
    for (int i = 1; i <= n; i++) {
        tmp *= i;
        ans += tmp;
    }
    printf("%lld\n", ans);
    return 0;
}