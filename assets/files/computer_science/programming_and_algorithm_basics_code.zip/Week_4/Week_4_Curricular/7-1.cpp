#include <bits/stdc++.h>

int n, sum;
int a[20];
double avg;

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        sum += a[i];
    }
    if (n >= 1 && n <= 10) {
        avg = (double)sum / n;
        printf("%.2lf\n", avg);
        for (int i = 0; i < n; i++) {
            if (a[i] > avg) {
                printf("%d ", a[i]);
            }
        }
        printf("\n");
    }
    else {
        printf("Invalid.\n");
    }
    return 0;
}