#include <bits/stdc++.h>

int n, ans, ind;
int a[20];

int main()
{
    ans = 0x3f3f3f3f;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        if (ans > a[i]) {
            ans = a[i], ind = i;
        }
    }
    printf("%d %d\n", ans, ind);
    return 0;
}