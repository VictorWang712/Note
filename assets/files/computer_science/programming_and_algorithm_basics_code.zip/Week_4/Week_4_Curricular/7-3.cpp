#include <bits/stdc++.h>

int a[11] = {1, 2, 4, 6, 8, 9, 12, 15, 149, 156, 0};

int main()
{
    scanf("%d", &a[10]);
    std::sort(a, a + 11);
    for (int i = 0; i < 11; i++) {
        printf("%5d", a[i]);
    }
    printf("\n");
    return 0;
}