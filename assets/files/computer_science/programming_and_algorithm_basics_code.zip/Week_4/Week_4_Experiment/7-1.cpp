#include <bits/stdc++.h>

int n;
int a[20];
bool ans = true;

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        if (i != 0 && a[i] > a[i - 1]) {
            ans = false;
        }
    }
    printf("%s\n", ans == true ? "Yes" : "No");
    return 0;
}