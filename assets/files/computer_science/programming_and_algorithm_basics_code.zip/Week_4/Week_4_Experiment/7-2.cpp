#include <bits/stdc++.h>

int a[20];

int main()
{
    for (int i = 0; i < 10; i++) {
        scanf("%d", &a[i]);
    }
    std::sort(a, a + 10);
    printf("max=%d,cmax=%d\n", a[9], a[8]);
    return 0;
}