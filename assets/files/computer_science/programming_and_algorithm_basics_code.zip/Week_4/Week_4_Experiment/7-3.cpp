#include <bits/stdc++.h>

int n;
int a[110];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < n; i += 2) {
        printf("%d%c", a[i], i + 2 < n ? ' ' : '\n');
    }
    if (n != 1) {
        for (int i = 1; i < n; i += 2) {
            printf("%d%c", a[i], i + 2 < n ? ' ' : '\n');
        }
    }
    else {
        printf("\n");
    }
    return 0;
}