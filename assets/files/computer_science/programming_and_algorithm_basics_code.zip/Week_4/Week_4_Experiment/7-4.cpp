#include <bits/stdc++.h>

int n;
int a[20];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    printf("The array has been inverted:\n");
    for (int i = 0; i < n; i++) {
        printf("%d,",a[n - 1 - i]);
    }
    printf("\n");
    return 0;
}