#include <bits/stdc++.h>

int n;
int a[20];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < n; i++) {
        printf("%4d", a[n - i - 1]);
    }
    printf("\n");
    return 0;
}