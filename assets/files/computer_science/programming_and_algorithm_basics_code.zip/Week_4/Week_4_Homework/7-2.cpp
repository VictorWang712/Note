#include <bits/stdc++.h>

int a[10];

int main()
{
    for (int i = 0; i < 8; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 3; i < 8; i++) {
        printf("%3d", a[i]);
    }
    for (int i = 0; i < 3; i++) {
        printf("%3d", a[i]);
    }
    printf("\n");
    return 0;
}