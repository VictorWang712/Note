#include <bits/stdc++.h>

int n;
int a[100];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i * 2 < n; i++) {
        printf("%d %d\n", a[i], a[n - i - 1]);
    }
    return 0;
}