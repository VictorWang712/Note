#include <bits/stdc++.h>

int n;
int a[10], x[100];

int main()
{
    for (int i = 0; i < 10; i++) {
        scanf("%d", &a[i]);
    }
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &x[i]);
        a[x[i] - 1] += 10;
    }
    for (int i = 0; i < 10; i++) {
        printf("%d%c", a[i], i == 9 ? '\n' : ' ');
    }
    return 0;
}