int vis[10];

int fun (int m, int n) {
    while (m != 0) {
        vis[m % 10] = 1;
        m /= 10;
    }
    return vis[n] == 1;
}