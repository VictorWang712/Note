int IsSquare(int n) {
    return sqrt(n) == (int)sqrt(n);
}