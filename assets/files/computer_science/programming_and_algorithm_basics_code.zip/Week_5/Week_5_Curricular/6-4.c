#include <math.h>

int Count_Digit (const int N, const int D) {
    int ret = 0, n = abs(N);
    while (n != 0) {
        if (n % 10 == D) {
            ret++;
        }
        n /= 10;
    }
    if(N == 0 && D == 0) {
        ret = 1;
    }
    return ret;
}