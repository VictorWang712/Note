int f(int m) {
    int ret = 0;
    while (m != 0) {
        ret += m % 10;
        m /= 10;
    }
    return ret;
}