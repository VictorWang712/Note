int fun(int a[], int n) {
    int ret = 0, max = -0x3f3f3f3f;
    for (int i = 0; i < n; i++) {
        if (a[i] > max) {
            ret = i, max = a[i];
        }
    }
    return ret;
}