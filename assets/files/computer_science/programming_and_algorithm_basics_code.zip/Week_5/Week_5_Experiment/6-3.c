float fun(int n) {
    float ret = 2 - 1 / (float)(n);
    return ret;
}