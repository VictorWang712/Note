int prime(int p) {
    int ret = 1;
    if (p <= 1) {
        ret = 0;
    }
    for (int i = 2; i * i <= p; i++) {
        if (p % i == 0) {
            ret = 0;
            break;
        }
    }
    return ret;
}

int PrimeSum(int m, int n) {
    int ret = 0;
    for (int i = m; i <= n; i++) {
        if (prime(i) == 1) {
            ret += i;
        }
    }
    return ret;
}