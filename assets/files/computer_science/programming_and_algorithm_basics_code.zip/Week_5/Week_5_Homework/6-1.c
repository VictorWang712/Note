void inv(int x[],int n) {
    for (int i = 0; i * 2 <= n; i++) {
        int tmp;
        tmp = x[i], x[i] = x[n - i - 1], x[n - i - 1] = tmp;
    }
    return;
}