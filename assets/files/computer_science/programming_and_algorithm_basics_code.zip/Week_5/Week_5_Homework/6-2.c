int fun(int x) {
    int ret = 0;
    while (x != 0) {
        ret++;
        x /= 10;
    }
    return ret;
}