#include<stdio.h> 
int twinNumber(int x, int y);
int main() 
{
     int n=0,a,b;
     scanf("%d%d",&a,&b);
     n = twinNumber(a,b);
     printf("%d\n",n); 
     return 0;
}
/* 请在这里填写答案 */

int IsPrime(int x) {
    int ret = 1;
    for (int i = 2; i * i <= x; i++) {
        if (x % i == 0) {
            ret = 0;
            break;
        }
    }
    if (x == 1) {
        ret = 0;
    }
    return ret;
}

int twinNumber(int x, int y) {
    int ret = 0;
    if (x > y) {
        int tmp;
        tmp = x, x = y, y = tmp;
    }
    for (int i = x; i <= y - 2; i++) {
        if (IsPrime(i) == 1 && IsPrime(i + 2) == 1) {
            ret++;
        }
    }
    return ret;
}