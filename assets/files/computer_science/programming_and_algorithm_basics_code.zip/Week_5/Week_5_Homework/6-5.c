    double mypow(double x, int n) {
        double ret = 1;
        for (int i = 0; i < n; i++) {
            ret *= x;
        }
        return ret;
    }