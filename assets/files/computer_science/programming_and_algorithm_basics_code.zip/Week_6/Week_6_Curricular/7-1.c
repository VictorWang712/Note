#include <stdio.h>
#define N 1000010

int n, ans, max;
int a[N], vis[N];

int main()
{
    max = -1;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        if (max < a[i]) {
            max = a[i];
        }   
    }
    for (int i = 0; i <= max; i++) {
        vis[i] = -1;
    }
    for (int i = 0; i < n; i++) {
        if (vis[a[i]] == -1) {
            vis[a[i]] = i; 
        }
    }
    for (int i = 0; i <= max; i++) {
        if (vis[i] != -1 && ans < vis[i]) {
            ans = vis[i];
        }
    }
    printf("%d\n", ans);
    return 0;
}