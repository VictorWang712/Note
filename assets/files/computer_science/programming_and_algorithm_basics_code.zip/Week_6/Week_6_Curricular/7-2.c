#include <stdio.h>
#define N 100010

int n, cnt;
int a[N], b[N], vis[N];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        if (vis[a[i]] == 0) {
            b[cnt++] = a[i];
            vis[a[i]] = 1;
        }   
    }
    for (int i = 0; i < cnt; i++) {
        printf("%d%c", b[i], i == cnt - 1 ? '\n' : ' ');
    }
    return 0;
}