#include <stdio.h>
#include <stdlib.h>
#define N 500010

int n, cnt;
int a[N];

int Compare(const void *a, const void *b) {
    int ret;
    ret = *(int *)a - *(int *)b;
    return ret;
}

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    qsort(a, n, sizeof(int), Compare);
    for (int i = 0; i < n; i++) {
        printf("%d%c", a[n - i - 1], i == cnt - 1 ? '\n' : ' ');
    }
    return 0;
}