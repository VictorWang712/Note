#include <bits/stdc++.h>
#define N 500010

int n, cnt;
int a[N];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    std::sort(a, a + n);
    for (int i = 0; i < n; i++) {
        printf("%d%c", a[n - i - 1], i == cnt - 1 ? '\n' : ' ');
    }
    return 0;
}