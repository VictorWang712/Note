#include <stdio.h>
#define N 20010

int n, ql, qr;
int queue[N];

int main()
{
    scanf("%d", &n);
    ql = 1;
    for (int i = 0; i < n; i++) {
        int op, x;
        scanf("%d", &op);
        if (op == 0) {
            if (ql > qr) {
                printf("invalid\n");
            }
            else {
                printf("%d\n", queue[ql]), ql++;
            }
        }
        else if (op == 1) {
            scanf("%d", &x);
            qr++, queue[qr] = x;
        }
    }
    return 0;
}