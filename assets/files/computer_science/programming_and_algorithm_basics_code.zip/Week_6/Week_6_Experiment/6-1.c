int cnt, flag;
int pr[10010];

int factorsum(int number) {
    int ret = 0;
    cnt = 0;
    for (int i = 0; i < 10001; i++) {
        pr[i] = 0;
    }
    for (int i = 1; i * 2 <= number; i++) {
        if (number % i == 0) {
            ret += i;
            pr[cnt] = i, cnt++;
        }
    }
    return ret;
}

void PrintPN(int m, int n) {
    flag = 0;
    for (int i = m; i <= n; i++) {
        if (factorsum(i) == i) {
            flag = 1;
            printf("%d = ", i);
            for (int j = 0; j < cnt - 1; j++) {
                printf("%d + ", pr[j]);
            }
            printf("%d\n", pr[cnt - 1]);
        }
    }
    if (flag == 0) {
        printf("No perfect number\n");
    }
    return;
}