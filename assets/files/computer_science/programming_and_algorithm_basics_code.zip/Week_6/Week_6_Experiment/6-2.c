void ArrayShift(int a[], int n, int m) {
    int b[100010];
    for (int i = 0; i < n; i++) {
        b[(i + m) % n] = a[i];
    }
    for (int i = 0; i < n; i++) {
        a[i] = b[i];
    }
    return;
}