int search(int n) {
    int ret = 0;
    for (int i = 101; i <= n; i++) {
        int a, b, c;
        a = (i / 100) % 10, b = (i / 10) % 10, c = (i / 1) % 10;
        if ((a == b || b == c || c == a) && (i == (int)sqrt(i) * (int)sqrt(i))) {
            ret++;
        }
    }
    return ret;
}