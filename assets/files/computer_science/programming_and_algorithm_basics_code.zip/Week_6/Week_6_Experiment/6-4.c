double fact(int n) {
    double ret = 1;
    for (int i = 1; i <= n; i++) {
        ret *= i;
    }
    return ret;