int search(int list[], int n, int x) {
    int ret = -1;
    for (int i = 0; i < n; i++) {
        if (list[i] == x) {
            ret = i;
            break;
        }
    }
    return ret;
}