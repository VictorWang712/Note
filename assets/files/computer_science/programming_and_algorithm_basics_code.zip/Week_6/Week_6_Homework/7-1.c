#include <stdio.h>
#define N 1010

int n, h, ans;
int a[N];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    scanf("%d", &h);
    for (int i = 0; i < n; i++) {
        if (a[i] <= h + 30) {
            ans++;
        }
    }
    printf("%d\n", ans);
    return 0;
}