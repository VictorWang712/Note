#include <stdio.h>
#define N 100010

int n, ans;
int a[N], vis[N];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n - 1; i++) {
        scanf("%d", &a[i]);
        vis[a[i]]++;
    }
    for (int i = 1; i <= 100000; i++) {
        if (vis[i] == 1) {
            ans = i;
        }
    }
    printf("%d\n", ans);
    return 0;
}