#include <stdio.h>

int max, ans;
int a[8];

int main()
{
    for (int i = 1; i <= 7; i++) {
        scanf("%d", &a[i]);
        if (i > 1 && a[i] != 0) {
            max = i;
        }
    }
    ans += (1 + max) * a[1];
    for (int i = 2; i <= 7; i++) {
        ans += i * a[i];
    }
    printf("%d\n", ans);
    return 0;
}