#include <stdio.h>
#define N 10010

int len, m, ans;
int road[N];

int main()
{
    scanf("%d", &len);
    for (int i = 0; i <= len; i++) {
        road[i] = 1;
    }
    scanf("%d", &m);
    for (int i = 0; i < m; i++) {
        int l, r;
        scanf("%d%d", &l, &r);
        for (int j = l; j <= r; j++) {
            road[j] = 0;
        }
    }
    for (int i = 0; i <= len; i++) {
        if (road[i] == 1) {
            ans++;
        }
    }
    printf("%d\n", ans);
    return 0;
}