#include <stdio.h>
#include <math.h>
#define N 110

int n, ans, ind;
int a[N], cnt[N], date[N];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        cnt[a[i]]++;
    }
    ind = 1, ans = 1;
    for (int i = 1; i <= 100; i++) {
        for (int j = 0; j < cnt[i]; j++) {
            if (ind > n) {
                ans = 0;
                break;
            }
            date[ind] = i;
            ind += 2;
        }
        if (ans == 0) {
            break;
        }
        for (int j = 1; j <= n; j++) {
            if (date[j] == 0) {
                ind = j;
                break;
            }
        }
    }
    printf("%s\n", ans == 1 ? "YES" : "NO");
    return 0;
}