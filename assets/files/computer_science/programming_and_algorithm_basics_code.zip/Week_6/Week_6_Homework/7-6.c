#include <stdio.h>
#define N 20010

int n, size;
int stack[N];

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        int op, x;
        scanf("%d", &op);
        if (op == 0) {
            if (size == 0) {
                printf("invalid\n");
            }
            else {
                printf("%d\n", stack[size]), size--;
            }
        }
        else if (op == 1) {
            scanf("%d", &x);
            size++, stack[size] = x;
        }
    }
    return 0;
}