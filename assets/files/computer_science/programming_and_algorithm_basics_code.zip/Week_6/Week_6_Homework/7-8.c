#include <stdio.h>
#include <math.h>
#define N 1010
#define EPS 0.000001

int n, m, ans, ind;
double a[N][N], q[N][N];

void Read() {
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            scanf("%lf", &a[i][j]);
        }
    }
    return;
}

int Equal(double a, double b) {
    int ret, delta;
    delta = a - b;
    if (delta < 0) {
        delta = -delta;
    }
    if (delta <= EPS) {
        ret = 1;
    }
    else {
        ret = 0;
    }
    return ret;
}

double Length(double *v) {
    double ret = 0;
    for (int i = 1; i <= n; i++) {
        ret += v[i] * v[i];
    }
    ret = sqrt(ret);
    return ret;
}

double InnerProduct(double *a, double *b) {
    double ret = 0;
    for (int i = 1; i <= n; i++) {
        ret += a[i] * b[i];
    }
    return ret;
}

void Orthogonalization(int i) {
    for (int j = 1; j <= n; j++) {
        q[i][j] = a[i][j];
    }
    for (int j = 1; j <= i - 1; j++) {
        double prd = InnerProduct(q[j], a[i]);
        for (int k = 1; k <=n; k++) {
            q[i][k] -= prd * q[j][k];
        }
    }
    return;
}

int Check(int i) {
    int ret = 1;
    for (int j = 1; j <= n; j++) {
        if (Equal(q[i][j], 0) == 0) {
            ret = 0;
            break;
        }
    }
    return ret;
}

void Normalization(int i) {
    double len = Length(q[i]);
    for (int j = 1; j <= n; j++) {
        q[i][j] /= len;
    }
    return;
}

void Solve() {
    for (int i = 1; i <= m; i++) {
        Orthogonalization(i);
        if(Check(i) == 1) {
            ans = i;
            break;
        }
        Normalization(i);
    }
    return;
}

void Print() {
    if (ans == 0) {
        printf("NO\n");
        for (int i = 1; i <= n; i++) {
            printf("%.2lf%c", q[m][i], i == n ? '\n' : ' ');
        }
    }
    else {
        printf("YES %d\n", ans);
    }
    return;
}

int main()
{
    Read();
    Solve();
    Print();
    return 0;
}