double Fac(int x) {
    double ret = 1;
    if (x == 0) {
        ret = 1;
    }
    else {
        ret = x * Fac(x - 1);
    }
    return ret;
}