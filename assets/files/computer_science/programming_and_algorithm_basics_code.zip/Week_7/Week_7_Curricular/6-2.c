int f(int n) {
    int ret;
    if (n == 0) {
        ret = 0;
    }
    else if (n == 1) {
        ret = 1;
    }
    else {
        ret = f(n - 2) + f(n - 1);
    }
    return ret;
}