int TopDigit(int number) {
    if (number < 10) {
        return number;
    }
    else {
        return TopDigit(number / 10);
    }
}