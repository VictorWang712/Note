double fact(int n) {
    if (n <= 1) {
        return 1;
    }
    else {
        return n * fact(n - 1);
    }
}

double factsum(int n) {
    double ret = 0;
    for (int i = 1; i <= n; i++) {
        ret += fact(i);
    }
    return ret;
}