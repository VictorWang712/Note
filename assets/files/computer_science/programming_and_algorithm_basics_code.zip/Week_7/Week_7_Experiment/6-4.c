long long Redup(int n, int d) {
    if (n == 0 || d == 0) {
        return 0;
    }
    else {
        return Redup(n - 1, d) * 10 + d;
    }
}