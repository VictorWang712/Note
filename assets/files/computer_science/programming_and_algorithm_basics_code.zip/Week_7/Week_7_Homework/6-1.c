#include <math.h>

double f(double x, double guess, double eps) {
    if (fabs(guess * guess - x) < eps) {
        return guess;
    }
    else {
        return f(x, (guess + x / guess) / 2, eps);
    }
}