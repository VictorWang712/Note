#include <stdio.h>

int n;

void Reverse(int x) {
    if (x < 10) {
        printf("%d", x);
    }
    else {
        printf("%d", x % 10);
        Reverse(x / 10);
    }
    return;
}

int main()
{
    scanf("%d", &n);
    Reverse(n);
    printf("\n");
    return 0;
}