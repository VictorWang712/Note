#include <stdio.h>

int n, a, b;
int f[100010];

int func(int n) {
    if (n == 1) {
        return f[1];
    }
    else {
        return func(n - 1) * a + b;
    }
}

int main()
{
    while (scanf("%d %d %d %d", &n, &f[1], &a, &b) == 4) {
        printf("%d\n", func(n));
    }
    return 0;
}