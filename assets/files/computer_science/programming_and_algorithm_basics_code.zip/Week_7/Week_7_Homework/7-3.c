#include <stdio.h>

int n;
char c[3];

void Recursion(int x, int u, int v, int w) {
    if (x == 1) {
        printf("%d: %c -> %c\n", x, u, v);
    }
    else {
        Recursion(x - 1, u, w, v);
        printf("%d: %c -> %c\n", x, u, v);
        Recursion(x - 1, w, v, u);
    }
    return;
}

int main()
{
    scanf("%d", &n);
    getchar(), scanf("%c %c %c", &c[0], &c[1], &c[2]);
    Recursion(n, c[0], c[1], c[2]);
    return 0;
}