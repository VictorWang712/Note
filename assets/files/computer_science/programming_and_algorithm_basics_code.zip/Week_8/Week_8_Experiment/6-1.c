#include <stdio.h>

int IsOdd(int x);
int IsEven(int x);
double NumRing(int index);

int main()
{
    int n;
    scanf("%d", &n);
    printf("%.15g\n", NumRing(n));
    return 0;
}

/* 你提交的代码将被嵌在这里 */

int IsOdd(int x) {
    if (x % 2 == 1) {
        return 1;
    }
    else {
        return 0;
    }
}

int IsEven(int x) {
    if (x % 2 == 0) {
        return 1;
    }
    else {
        return 0;
    }
}

double NumRing(int index) {
    if (index <= 0) {
        return 0;
    }
    else if (index == 1) {
        return 1;
    }
    else if (IsOdd(index) == 1) {
        return NumRing(index - 1) * 2 + 1;
    }
    else if (IsEven(index) == 1) {
        return NumRing(index - 1) * 2;
    }
    return 0;
}