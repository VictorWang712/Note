#define EPS 0.000001

double bisection(double (*f)(double), double a, double b) {
    for (int i = 0; i < 1000; i++) {
        double mid = (a + b) / 2.0;
        if (f(mid) < EPS && f(mid) > -EPS) {
            return mid;
        }
        else if (f(mid) * f(a) < 0) {
            b = mid;
        }
        else {
            a = mid;
        }
    }
    return -32768;
}