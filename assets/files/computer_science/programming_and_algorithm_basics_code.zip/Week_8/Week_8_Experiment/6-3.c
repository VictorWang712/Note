void selectionSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int min = 0x3f3f3f3f, ind = -1;
        for (int j = i; j < n; j++) {
            if (arr[j] < min) {
                ind = j, min = arr[j];
            }
        }
        int tmp;
        tmp = arr[i], arr[i] = arr[ind], arr[ind] = tmp;
    }
    return;
}