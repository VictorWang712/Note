#include <stdio.h>
#define N 10
void sort(int a[],int n,int m);
int  main( )
{    
int a[N],n,m,i;
scanf("%d%d",&n,&m);
for (int i = 0; i <n;i++) {
    scanf("%d", &a[i]);
}
sort(a,n,m);
for(i=0;i<n;i++)
    printf("%d ",a[i]);
printf("\n");
return 0;
}

/* 请在这里填写答案 */

void sort(int a[],int n,int m) {
    for (int i = 0; i < m; i++) {
        for (int j = n - 1; j > i; j--) {
            if (a[j] > a[j - 1]) {
                int tmp;
                tmp = a[j], a[j] = a[j - 1], a[j - 1] = tmp;
            }
        }
    }
    return;
}