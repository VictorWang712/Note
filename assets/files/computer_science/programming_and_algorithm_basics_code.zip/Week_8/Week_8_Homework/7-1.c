#include <stdio.h>
#define N 20

int n, x, flag = 1, ans;
int a[N];

void BinarySearch(int l, int r) {
    int mid = (l + r) / 2;
    if (l > r) {
        ans = -1;
        return;
    }
    printf("[%d,%d][%d]\n", l, r, mid);
    if (a[mid] == x) {
        ans = mid;
        return;
    }
    else if (a[mid] < x) {
        BinarySearch(mid + 1, r);
    }
    else if (a[mid] > x) {
        BinarySearch(l, mid - 1);
    }
    return;
}

int main()
{
    scanf("%d %d", &n, &x);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < n - 1; i++) {
        if (a[i] >= a[i + 1]) {
            flag = 0;
            break;
        }
    }
    if (flag == 1) {
        BinarySearch(0, n - 1);
        if (ans != -1) {
            printf("%d\n", ans);
        }
        else {
            printf("Not Found\n");
        }
    }
    else {
        printf("Invalid Value\n");
    }
    return 0;
}