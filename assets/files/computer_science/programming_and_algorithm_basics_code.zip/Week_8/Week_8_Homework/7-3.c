#include <stdio.h>
#define N 20

int n;
int a[N];

void BubbleSort(int x) {
    for (int i = 0; i < n - x - 1; i++) {
        if (a[i] > a[i + 1]) {
            int tmp;
            tmp = a[i], a[i] = a[i + 1], a[i + 1] = tmp;
        }
    }
    for (int i = 0; i < n; i++) {
        printf("%d%c", a[i], i == n - 1 ? '\n' : ' ');
    }
    return;
}

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (int i = 0; i < n - 1; i++) {
        BubbleSort(i);
    }
    if (n == 1) {
        printf("%d\n", a[0]);
    }
    return 0;
}