void MergeSort(int* a, int l, int r) {
    if (l == r) {
        return;
    }
    int mid = (l + r) / 2, cnt = 0, ind1 = l, ind2 = mid + 1;
    MergeSort(a, l, mid), MergeSort(a, mid + 1, r);
    int tmp[r - l + 10];
    while (ind1 <= mid && ind2 <= r) {
        if (a[ind1] <= a[ind2]) {
            tmp[cnt] = a[ind1], cnt++, ind1++;
        }
        else if (a[ind1] > a[ind2]) {
            tmp[cnt] = a[ind2], cnt++, ind2++;
        }
    }
    while (ind1 <= mid) {
        tmp[cnt] = a[ind1], cnt++, ind1++;
    }
    while (ind2 <= r) {
        tmp[cnt] = a[ind2], cnt++, ind2++;
    }
    for (int i = 0; i < cnt; i++) {
        a[l + i] = tmp[i];
    }
    return;
}

void sort(int a[], int len) {
    MergeSort(a, 0, len - 1);
    return;
}