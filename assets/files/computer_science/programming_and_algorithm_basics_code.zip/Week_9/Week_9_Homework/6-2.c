double Cmb(int x, int y) {
    y = IntMin(y, x - y);
    if (y < 0) {
        return 0;
    }
    else if (y == 0) {
        return 1;
    }
    else {
        return Cmb(x - 1, y - 1) * x / y;
    }
}